"use strict";
var Animal = (function () {
    function Animal(type, domestic, carnivore) {
        this.type = type;
        this.domestic = domestic;
        this.carnivore = carnivore;
    }
    return Animal;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Animal;

//# sourceMappingURL=animal.js.map
