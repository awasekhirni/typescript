var Customer = (function () {
    function Customer(name, type, id, email, phone) {
        this.name = name;
        this.type = type;
        this.id = id;
        this.email = email;
        this.phone = phone;
    }
    Customer.prototype.getName = function () {
        return this.name;
    };
    return Customer;
}());

//# sourceMappingURL=customer.js.map
