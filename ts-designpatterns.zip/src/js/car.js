"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var vehicle_1 = require("./vehicle");
var Car = (function (_super) {
    __extends(Car, _super);
    function Car(mpg, fuel) {
        _super.call(this, mpg, fuel);
        this.name = "Car";
        this._tires = new Tire(TireType.HIGH_PERFORMANCE);
        this.soundSystem = new CDPlayer();
        console.log(this.name, "has", this._tires.getType(), "tires");
    }
    Car.prototype.useAccessory = function () {
        this.openSunroof();
    };
    Car.prototype.openSunroof = function () {
        console.log(this.name, "opened sunroof");
    };
    return Car;
}(vehicle_1.Vehicle));
O;

//# sourceMappingURL=car.js.map
