"use strict";
var events_1 = require("events");
var OrderManagementSystem = (function () {
    function OrderManagementSystem() {
        var _this = this;
        this.messageBus = new events_1.EventEmitter();
        this.messageBus.on("order", function (orderMessage) {
            _this.processOrder(orderMessage);
        });
        this.messageBus.on("execution", function (executionMessage) {
            _this.processExecution(executionMessage);
        });
    }
    OrderManagementSystem.prototype.processExecution = function (execution) {
        console.log(new Date().getTime() + ":OMS:execution:" + JSON.stringify(execution));
    };
    OrderManagementSystem.prototype.processOrder = function (order) {
        console.log(new Date().getTime() + ":OMS:order:" + JSON.stringify(order));
        var numberOfExecutions = 10;
        var quantityPerExecution = order.quantity / numberOfExecutions;
        for (var i = 0; i < numberOfExecutions; i++) {
            this.messageBus.emit("execution", {
                orderId: order.orderId,
                executionId: i,
                symbol: order.symbol,
                quantity: quantityPerExecution,
                price: 101.5
            });
        }
    };
    return OrderManagementSystem;
}());
exports.OrderManagementSystem = OrderManagementSystem;

//# sourceMappingURL=ordermgmtsystem.js.map
