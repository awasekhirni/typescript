"use strict";
var events_1 = require('events');
var ComplianceSystem = (function () {
    function ComplianceSystem() {
        var _this = this;
        this.messageBus = new events_1.EventEmitter();
        this.messageBus.on("order", function (orderMessage) {
            _this.trackOrder(orderMessage);
        });
        this.messageBus.on("execution", function (executionMessage) {
            _this.trackExecution(executionMessage);
        });
    }
    ComplianceSystem.prototype.trackOrder = function (order) {
        console.log(new Date().getTime() + ":COMPLIANCE:order:" + JSON.stringify(order));
    };
    ComplianceSystem.prototype.trackExecution = function (execution) {
        console.log(new Date().getTime() + ":COMPLIANCE:execution:" + JSON.stringify(execution));
    };
    return ComplianceSystem;
}());
exports.ComplianceSystem = ComplianceSystem;

//# sourceMappingURL=compliancesystem.js.map
