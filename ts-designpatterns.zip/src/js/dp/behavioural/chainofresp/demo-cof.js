"use strict";
var ordermgmtsystem_1 = require("./ordermgmtsystem");
var compliancesystem_1 = require("./compliancesystem");
var ooms = new ordermgmtsystem_1.OrderManagementSystem();
var cms = new compliancesystem_1.ComplianceSystem();
//order
//tracking 

//# sourceMappingURL=demo-cof.js.map
