"use strict";
Carnivore;
{
    attackforFood();
    string;
}

//# sourceMappingURL=carnivore.js.map
