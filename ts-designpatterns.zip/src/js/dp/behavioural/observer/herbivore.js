"use strict";
var Herbivore = (function () {
    function Herbivore() {
    }
    Herbivore.prototype.addCarnivore = function (carnivore) {
        this.carnivores.push(carnivore);
    };
    Herbivore.prototype.notifyAll = function () {
        var scene = "";
        for (var _i = 0, _a = this.carnivores; _i < _a.length; _i++) {
            var carnivore = _a[_i];
            scene += carnivore.attackforFood();
        }
        return scene;
    };
    return Herbivore;
}());

//# sourceMappingURL=herbivore.js.map
