"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var herbivore_1 = require("./herbivore");
var Sheep = (function (_super) {
    __extends(Sheep, _super);
    function Sheep() {
        _super.call(this);
    }
    Sheep.prototype.shout = function () {
        throw new Error("Method not implemented.");
    };
    return Sheep;
}(herbivore_1.default));
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Sheep;

//# sourceMappingURL=sheep.js.map
