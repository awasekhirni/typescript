"use strict";
var tiger_1 = require("./tiger");
var fox_1 = require("./fox");
var deer_1 = require("./deer");
var sharekhan = new tiger_1.default(), lomdi = new fox_1.default();
var dolly = new deer_1.default();
dolly.addCarnivore(sharekhan);
dolly.addCarnivore(lomdi);
console.log(dolly.notifyAll());

//# sourceMappingURL=demo.js.map
