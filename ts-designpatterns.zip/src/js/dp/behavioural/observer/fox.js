"use strict";
var Fox = (function () {
    function Fox() {
    }
    Fox.prototype.attackforFood = function () {
        return "Foxy is attacking, i had no food since 3 days";
    };
    return Fox;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Fox;

//# sourceMappingURL=fox.js.map
