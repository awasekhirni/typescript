"use strict";
var Tiger = (function () {
    function Tiger() {
    }
    Tiger.prototype.attackforFood = function () {
        return "Tiger is attacking, i had no food since 3 days";
    };
    return Tiger;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Tiger;

//# sourceMappingURL=tiger.js.map
