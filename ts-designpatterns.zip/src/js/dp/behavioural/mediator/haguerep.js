"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var representative_1 = require('./representative');
var HagueRepresentative = (function (_super) {
    __extends(HagueRepresentative, _super);
    function HagueRepresentative(mediator) {
        _super.call(this, mediator);
    }
    HagueRepresentative.prototype.send = function (msg) {
        console.log("Message from HagueRepresentative");
        _super.prototype.send.call(this, msg);
    };
    return HagueRepresentative;
}(representative_1.Representative));
exports.HagueRepresentative = HagueRepresentative;

//# sourceMappingURL=haguerep.js.map
