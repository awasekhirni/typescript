"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var representative_1 = require('./representative');
var UNRepresentative = (function (_super) {
    __extends(UNRepresentative, _super);
    function UNRepresentative(mediator) {
        _super.call(this, mediator);
    }
    UNRepresentative.prototype.send = function (msg) {
        console.log("message from UN representative");
        _super.prototype.send.call(this, msg);
    };
    return UNRepresentative;
}(representative_1.Representative));
exports.UNRepresentative = UNRepresentative;

//# sourceMappingURL=unrep.js.map
