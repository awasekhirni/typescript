"use strict";
var haguerep_1 = require('./haguerep');
var unrep_1 = require('./unrep');
var foreignsecretary_1 = require('./foreignsecretary');
var rep = new foreignsecretary_1.ForeignSecretary();
var trump = new unrep_1.UNRepresentative(rep);
var kimjong = new haguerep_1.HagueRepresentative(rep);
rep.USForeignSecretary = trump;
rep.DPRKForeignSecretary = kimjong;
trump.send("hello! rocket man, i am going to ship you to mars");
kimjong.send("hello,dumbo, america is planning to ship you to saturn");
console.log("we are happy in earth without you ALL, please go and fight somewhere else!!");

//# sourceMappingURL=demo.js.map
