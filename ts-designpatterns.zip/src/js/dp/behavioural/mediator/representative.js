"use strict";
var Representative = (function () {
    function Representative(mediator) {
        this.mediator = mediator;
    }
    Representative.prototype.send = function (msg) {
        this.mediator.send(msg, this);
    };
    Representative.prototype.receiveMsg = function (msg) {
        console.log(msg);
    };
    return Representative;
}());
exports.Representative = Representative;

//# sourceMappingURL=representative.js.map
