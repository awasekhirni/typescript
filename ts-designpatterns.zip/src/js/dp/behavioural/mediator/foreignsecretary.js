"use strict";
var ForeignSecretary = (function () {
    function ForeignSecretary() {
    }
    ForeignSecretary.prototype.send = function (message, sender) {
        if (sender === this.USForeignSecretary) {
            this.USForeignSecretary.receiveMsg(message);
            this.DPRKForeignSecretary.receiveMsg(message);
        }
        if (sender === this.DPRKForeignSecretary) {
            this.USForeignSecretary.receiveMsg(message);
        }
    };
    return ForeignSecretary;
}());
exports.ForeignSecretary = ForeignSecretary;

//# sourceMappingURL=foreignsecretary.js.map
