"use strict";
var Swimming = (function () {
    function Swimming() {
    }
    Swimming.prototype.burnCalories = function () {
        console.log('You have burn calories by swimming');
    };
    Swimming.prototype.dietaryIntake = function () {
        console.log('You have take gluten-free diet');
    };
    Swimming.prototype.stop = function () {
        console.log('stop and take rest');
    };
    Swimming.prototype.schedule = function () {
        console.log('everyday, morning 15laps and evening 15 laps');
    };
    Swimming.prototype.weightWatch = function () {
        console.log('only decreases 500gm in 1 week, do more: You want to be like salman khan!!');
    };
    return Swimming;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Swimming;

//# sourceMappingURL=swimming.js.map
