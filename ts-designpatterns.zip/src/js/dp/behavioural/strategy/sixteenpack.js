"use strict";
var SixteenPack = (function () {
    function SixteenPack(name, strategy) {
        this.name = name;
        this.strategy = strategy;
    }
    SixteenPack.prototype.fitnessplan = function () {
        console.log(this.name + " start the fitness plan:");
        this.strategy.burnCalories();
    };
    return SixteenPack;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = SixteenPack;

//# sourceMappingURL=sixteenpack.js.map
