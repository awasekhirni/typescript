"use strict";
var Aerobics = (function () {
    function Aerobics() {
    }
    Aerobics.prototype.burnCalories = function () {
        console.log('You have burn calories by aerobics');
    };
    Aerobics.prototype.dietaryIntake = function () {
        console.log('You have take gluten-free diet');
    };
    Aerobics.prototype.stop = function () {
        console.log('stop and take rest');
    };
    Aerobics.prototype.schedule = function () {
        console.log('everyday, morning 1hour and evening 1hour');
    };
    Aerobics.prototype.weightWatch = function () {
        console.log('only decreases 500gm in 1 week, do more: You want to be like salman khan!!');
    };
    return Aerobics;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Aerobics;

//# sourceMappingURL=aerobics.js.map
