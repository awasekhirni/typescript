"use strict";
var sixteenpack_1 = require("./sixteenpack");
var running_1 = require("./running");
var syedawase = new sixteenpack_1.default('Syed Awase', new running_1.default());
syedawase.fitnessplan();

//# sourceMappingURL=demo-st.js.map
