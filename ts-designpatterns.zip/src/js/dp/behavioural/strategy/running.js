"use strict";
var Running = (function () {
    function Running() {
    }
    Running.prototype.burnCalories = function () {
        console.log('You have burn calories by running');
    };
    Running.prototype.dietaryIntake = function () {
        console.log('You have take gluten-free diet');
    };
    Running.prototype.stop = function () {
        console.log('stop and take rest');
    };
    Running.prototype.schedule = function () {
        console.log('everyday, morning 5 kms and evening 5 kms');
    };
    Running.prototype.weightWatch = function () {
        console.log('only decreases 100gm in 1 week, do more: You want to be like salman khan!!');
    };
    return Running;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Running;

//# sourceMappingURL=running.js.map
