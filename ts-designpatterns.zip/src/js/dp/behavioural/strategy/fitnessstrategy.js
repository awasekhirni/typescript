"use strict";
FitnessStrategy;
{
    burnCalories();
    void ;
    dietaryIntake();
    void ;
    stop ?  : ;
    schedule();
    void ;
    weightWatch();
    void ;
}

//# sourceMappingURL=fitnessstrategy.js.map
