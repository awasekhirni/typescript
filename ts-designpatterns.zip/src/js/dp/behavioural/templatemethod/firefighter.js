"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var worker_1 = require('./worker');
var Firefighter = (function (_super) {
    __extends(Firefighter, _super);
    function Firefighter() {
        _super.apply(this, arguments);
    }
    Firefighter.prototype.DailyRoutine = function () {
        throw new Error("Method not implemented.");
    };
    Firefighter.prototype.getUp = function () {
        throw new Error("Method not implemented.");
    };
    Firefighter.prototype.eatBreakfast = function () {
        throw new Error("Method not implemented.");
    };
    Firefighter.prototype.goToWork = function () {
        throw new Error("Method not implemented.");
    };
    //override this to differentiate
    Firefighter.prototype.work = function () {
        throw new Error("Method not implemented.");
    };
    Firefighter.prototype.returnToHome = function () {
        throw new Error("Method not implemented.");
    };
    Firefighter.prototype.relax = function () {
        throw new Error("Method not implemented.");
    };
    Firefighter.prototype.sleep = function () {
        throw new Error("Method not implemented.");
    };
    return Firefighter;
}(worker_1.default));
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Firefighter;

//# sourceMappingURL=firefighter.js.map
