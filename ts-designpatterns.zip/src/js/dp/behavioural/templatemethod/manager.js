"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var worker_1 = require('./worker');
var Manager = (function (_super) {
    __extends(Manager, _super);
    function Manager() {
        _super.apply(this, arguments);
    }
    Manager.prototype.DailyRoutine = function () {
        throw new Error("Method not implemented.");
    };
    Manager.prototype.getUp = function () {
        throw new Error("Method not implemented.");
    };
    Manager.prototype.eatBreakfast = function () {
        throw new Error("Method not implemented.");
    };
    Manager.prototype.goToWork = function () {
        throw new Error("Method not implemented.");
    };
    Manager.prototype.work = function () {
        throw new Error("Method not implemented.");
    };
    Manager.prototype.returnToHome = function () {
        throw new Error("Method not implemented.");
    };
    Manager.prototype.relax = function () {
        throw new Error("Method not implemented.");
    };
    Manager.prototype.sleep = function () {
        throw new Error("Method not implemented.");
    };
    return Manager;
}(worker_1.default));
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Manager;

//# sourceMappingURL=manager.js.map
