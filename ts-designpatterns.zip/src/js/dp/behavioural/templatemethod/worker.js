"use strict";
var Worker = (function () {
    function Worker() {
    }
    return Worker;
}());

//# sourceMappingURL=worker.js.map
