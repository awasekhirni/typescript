"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var worker_1 = require('./worker');
var Lumberjack = (function (_super) {
    __extends(Lumberjack, _super);
    function Lumberjack() {
        _super.apply(this, arguments);
    }
    Lumberjack.prototype.DailyRoutine = function () {
        throw new Error("Method not implemented.");
    };
    Lumberjack.prototype.getUp = function () {
        throw new Error("Method not implemented.");
    };
    Lumberjack.prototype.eatBreakfast = function () {
        throw new Error("Method not implemented.");
    };
    Lumberjack.prototype.goToWork = function () {
        throw new Error("Method not implemented.");
    };
    Lumberjack.prototype.work = function () {
        throw new Error("Method not implemented.");
    };
    Lumberjack.prototype.returnToHome = function () {
        throw new Error("Method not implemented.");
    };
    Lumberjack.prototype.relax = function () {
        throw new Error("Method not implemented.");
    };
    Lumberjack.prototype.sleep = function () {
        throw new Error("Method not implemented.");
    };
    return Lumberjack;
}(worker_1.default));
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Lumberjack;

//# sourceMappingURL=lumberjack.js.map
