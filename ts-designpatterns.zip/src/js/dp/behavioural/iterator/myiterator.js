"use strict";
MyIterator < T > {
    next: function () { },
    hasNext: function () { }
};

//# sourceMappingURL=myiterator.js.map
