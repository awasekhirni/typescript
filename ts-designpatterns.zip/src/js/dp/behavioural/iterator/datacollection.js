"use strict";
var concreteiterator_1 = require('./concreteiterator');
var DataCollection = (function () {
    function DataCollection(collection) {
        this._collection = [];
        this._collection = collection;
    }
    DataCollection.prototype.createIterator = function () {
        return new concreteiterator_1.default(this._collection);
    };
    return DataCollection;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = DataCollection;

//# sourceMappingURL=datacollection.js.map
