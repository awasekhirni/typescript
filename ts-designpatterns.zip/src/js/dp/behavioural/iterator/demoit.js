"use strict";
var datacollection_1 = require('./datacollection');
var dc = new datacollection_1.default([112, 117, 161628, 17818712, 187198]);
var itr = dc.createIterator();
while (itr.hasNext()) {
    var number = itr.next();
    console.log("logging values:" + number.valueOf());
}

//# sourceMappingURL=demoit.js.map
