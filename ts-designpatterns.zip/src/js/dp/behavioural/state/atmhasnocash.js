"use strict";
var ATMNoCashState = (function () {
    function ATMNoCashState(machine, name) {
        this.name = name;
        this._machine = machine;
    }
    ATMNoCashState.prototype.takeCash = function (cash) {
        throw new Error('ATMMachine has no cash');
    };
    return ATMNoCashState;
}());
exports.ATMNoCashState = ATMNoCashState;

//# sourceMappingURL=atmhasnocash.js.map
