"use strict";
var ATMHasCashState = (function () {
    function ATMHasCashState(machine, name) {
        this.name = name;
        this._machine = machine;
    }
    ATMHasCashState.prototype.takeCash = function (cash) {
        if (this._machine.cash < cash) {
            this._machine.state = this._machine.noCashState();
            console.log('Not enough cash');
            return;
        }
        else if (this._machine.cash === cash) {
            this._machine.state = this._machine.noCashState();
            console.log('No cash after cash token');
        }
        console.log(this._machine.cash + " - " + cash);
        this._machine.cash -= cash;
    };
    return ATMHasCashState;
}());
exports.ATMHasCashState = ATMHasCashState;

//# sourceMappingURL=atmhaschash.js.map
