"use strict";
var atmhasnocash_1 = require('./atmhasnocash');
var atmhaschash_1 = require('./atmhaschash');
var ATMMachine = (function () {
    function ATMMachine(cash) {
        this.cash = cash;
        this._hasCashState = new atmhaschash_1.ATMHasCashState(this, 'HasCash');
        this._noCashState = new atmhasnocash_1.ATMNoCashState(this, 'NoCash');
        this._currentState = this.cash ? this._hasCashState : this._noCashState;
    }
    Object.defineProperty(ATMMachine.prototype, "state", {
        get: function () {
            return this._currentState;
        },
        set: function (value) {
            console.log("Current state is " + value.name);
            this._currentState = value;
        },
        enumerable: true,
        configurable: true
    });
    ATMMachine.prototype.takeCash = function (cash) {
        this._currentState.takeCash(cash);
    };
    // Get states
    ATMMachine.prototype.hasCashState = function () {
        return this._hasCashState;
    };
    ATMMachine.prototype.noCashState = function () {
        return this._noCashState;
    };
    return ATMMachine;
}());
exports.ATMMachine = ATMMachine;

//# sourceMappingURL=atmmachine.js.map
