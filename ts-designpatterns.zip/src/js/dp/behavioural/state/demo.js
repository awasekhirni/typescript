"use strict";
var atmmachine_1 = require("./atmmachine");
var mymac = new atmmachine_1.ATMMachine(10000);
mymac.takeCash(2000); // allows withdraw
mymac.takeCash(3000000); //error, does not have cash.

//# sourceMappingURL=demo.js.map
