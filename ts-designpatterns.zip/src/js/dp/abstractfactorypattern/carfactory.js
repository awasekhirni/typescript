"use strict";
var CarFactory;
(function (CarFactory) {
    (function (CarType) {
        CarType[CarType["Nano"] = 0] = "Nano";
        CarType[CarType["Compact"] = 1] = "Compact";
        CarType[CarType["Sedan"] = 2] = "Sedan";
        CarType[CarType["Muv"] = 3] = "Muv";
        CarType[CarType["Suv"] = 4] = "Suv";
        CarType[CarType["Uv"] = 5] = "Uv";
        CarType[CarType["Offroader"] = 6] = "Offroader";
        CarType[CarType["Pickup"] = 7] = "Pickup";
    })(CarFactory.CarType || (CarFactory.CarType = {}));
    var CarType = CarFactory.CarType;
    var TataNano = (function () {
        function TataNano() {
            this.engineType = "small";
            this.seatingCapacity = 2;
            this.length = 3.2;
            this.width = 3.6;
        }
        TataNano.prototype.engineStart = function () {
            return true;
        };
        TataNano.prototype.applyBrake = function () {
            return true;
        };
        TataNano.prototype.accelerate = function () {
            return true;
        };
        return TataNano;
    }());
    CarFactory.TataNano = TataNano;
    var TataBolt = (function () {
        function TataBolt() {
            this.engineType = "medium";
            this.seatingCapacity = 4;
            this.length = 4.8;
            this.width = 4.2;
        }
        TataBolt.prototype.engineStart = function () {
            return true;
        };
        TataBolt.prototype.applyBrake = function () {
            return true;
        };
        TataBolt.prototype.accelerate = function () {
            return true;
        };
        return TataBolt;
    }());
    CarFactory.TataBolt = TataBolt;
    var TataSafari = (function () {
        function TataSafari() {
            this.engineType = "large";
            this.seatingCapacity = 7;
            this.length = 6.2;
            this.width = 5.2;
        }
        TataSafari.prototype.engineStart = function () {
            return true;
        };
        TataSafari.prototype.applyBrake = function () {
            return true;
        };
        TataSafari.prototype.accelerate = function () {
            return true;
        };
        return TataSafari;
    }());
    CarFactory.TataSafari = TataSafari;
    var SilguriCarFactory = (function () {
        function SilguriCarFactory() {
            this.make = "TATA";
            this.manufacture = "TATA SONS";
        }
        SilguriCarFactory.prototype.BuildCar = function (carType) {
            var car = null;
            switch (carType) {
                case carType.Nano:
                    car = new TataNano();
                    break;
                case carType.Compact:
                    car = new TataBolt();
                    break;
                case carType.Suv:
                    car = new TataSafari();
                    break;
            }
            return car;
        };
        return SilguriCarFactory;
    }());
    CarFactory.SilguriCarFactory = SilguriCarFactory;
    var Demo;
    (function (Demo) {
        function display() {
            var mynano = new SilguriCarFactory();
            mynano.BuildCar(0);
            mynano.BuildCar(1);
            mynano.BuildCar(4);
        }
        Demo.display = display;
    })(Demo = CarFactory.Demo || (CarFactory.Demo = {}));
})(CarFactory = exports.CarFactory || (exports.CarFactory = {}));

//# sourceMappingURL=carfactory.js.map
