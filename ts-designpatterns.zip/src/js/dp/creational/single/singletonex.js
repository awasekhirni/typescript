"use strict";
var Bachelor = (function () {
    function Bachelor() {
    }
    Bachelor.getInstance = function () {
        if (!Bachelor.instance) {
            Bachelor.instance = new Bachelor();
            Bachelor.instance._age = 16;
        }
        return Bachelor.instance;
    };
    Object.defineProperty(Bachelor.prototype, "age", {
        get: function () {
            return this._age;
        },
        set: function (myage) {
            this._age = myage;
        },
        enumerable: true,
        configurable: true
    });
    Bachelor.prototype.increaseAge = function () {
        return this._age += 1;
    };
    Bachelor.prototype.decreaseAge = function () {
        return this._age -= 1;
    };
    return Bachelor;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Bachelor;

//# sourceMappingURL=singletonex.js.map
