"use strict";
//client for configurationmgr
var cm = require('./configmgr');
console.log(cm.config.getMaxAllow);
console.log(cm.config.getMaxConcurrentDevices());

//# sourceMappingURL=democonfigmgr.js.map
