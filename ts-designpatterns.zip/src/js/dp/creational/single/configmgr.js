"use strict";
//configmgr.ts =>configuration manager
//npm install node-env-run --save-dev
var config;
(function (config) {
    var Max_Connections_allowed = 10;
    var DEVICES_PER_CONNECTION = 25;
    function getMaxAllow() {
        return process.env[Max_Connections_allowed];
    }
    config.getMaxAllow = getMaxAllow;
    function getMaxConcurrentDevices() {
        return DEVICES_PER_CONNECTION * getMaxAllow();
    }
    config.getMaxConcurrentDevices = getMaxConcurrentDevices;
})(config = exports.config || (exports.config = {}));

//# sourceMappingURL=configmgr.js.map
