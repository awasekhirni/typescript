"use strict";
var singletonex_1 = require('./singletonex');
//const aicy=new Bachelor();
var aicy = singletonex_1.default.getInstance();
console.log(aicy.age);
console.log(aicy.age = 25);
var rayyan = singletonex_1.default.getInstance();
console.log(rayyan === aicy);

//# sourceMappingURL=singledemo.js.map
