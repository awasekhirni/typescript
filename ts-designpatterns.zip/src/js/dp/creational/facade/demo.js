"use strict";
var preloanchecks_1 = require('./preloanchecks');
var loanReq = new preloanchecks_1.default(2428812889128913);
loanReq.takeLoan();

//# sourceMappingURL=demo.js.map
