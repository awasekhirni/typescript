"use strict";
var loancontract_1 = require('./loancontract');
var companyfunds_1 = require('./companyfunds');
var PreLoanChecks = (function () {
    function PreLoanChecks(loanAmount) {
        this.contract = new loancontract_1.default(new Date(new Date().setDate(new Date().getDate() + 10)));
        this.funds = new companyfunds_1.default(2000000000);
        this.userContract = new Date();
        this.loanAmount = loanAmount;
    }
    PreLoanChecks.prototype.takeLoan = function () {
        if (this.contract.checkAnyloans(this.userContract)) {
            console.log('User has active loan');
        }
        else {
            console.log('User has no active loan');
            if (!this.funds.checkFunds(this.loanAmount)) {
                console.log('the loan amount req is high');
            }
            else {
                console.log('user can be given loan');
            }
        }
    };
    return PreLoanChecks;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = PreLoanChecks;

//# sourceMappingURL=preloanchecks.js.map
