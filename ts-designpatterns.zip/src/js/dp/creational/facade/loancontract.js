// facade pattern: used when there are multiple subsystem(multiple APIs)available for the application 
// loan application to a bank checks for credit rating, fraud systems, other loan information. 
"use strict";
var LoanContract = (function () {
    function LoanContract(endDate) {
        this.loanEndDate = endDate;
    }
    LoanContract.prototype.checkAnyloans = function (date) {
        if (date < this.loanEndDate) {
            return true;
        }
        else {
            return false;
        }
    };
    return LoanContract;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = LoanContract;

//# sourceMappingURL=loancontract.js.map
