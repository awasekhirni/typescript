"use strict";
var CompanyFunds = (function () {
    function CompanyFunds(ttlamount) {
        this.fundBalance = ttlamount;
    }
    CompanyFunds.prototype.checkFunds = function (transactionFee) {
        if (transactionFee < this.fundBalance) {
            return true;
        }
    };
    return CompanyFunds;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = CompanyFunds;

//# sourceMappingURL=companyfunds.js.map
