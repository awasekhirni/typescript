"use strict";
var bp = require('./brickprototype');
var test = new bp.BrickPrototype.Builder();
console.log(test);

//# sourceMappingURL=demopp.js.map
