"use strict";
var BrickPrototype;
(function (BrickPrototype) {
    var CementBrick = (function () {
        function CementBrick() {
        }
        CementBrick.prototype.clone = function () {
            return new CementBrick();
        };
        CementBrick.prototype.toString = function () {
            return "this is a CementBrick";
        };
        return CementBrick;
    }());
    BrickPrototype.CementBrick = CementBrick;
    var RedBrick = (function () {
        function RedBrick() {
        }
        RedBrick.prototype.clone = function () {
            return new RedBrick();
        };
        RedBrick.prototype.toString = function () {
            return "this is a redbrick";
        };
        return RedBrick;
    }());
    BrickPrototype.RedBrick = RedBrick;
    var Builder = (function () {
        function Builder() {
            this.prototypeMap = {};
            this.prototypeMap['brick1'] = new CementBrick();
            this.prototypeMap['brick2'] = new RedBrick();
        }
        Builder.prototype.createOne = function (s) {
            console.log(s);
            return this.prototypeMap[s].clone();
        };
        return Builder;
    }());
    BrickPrototype.Builder = Builder;
})(BrickPrototype = exports.BrickPrototype || (exports.BrickPrototype = {}));

//# sourceMappingURL=brickprototype.js.map
