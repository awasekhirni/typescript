"use strict";
var productimpl_1 = require('./productimpl');
var s7 = new productimpl_1.default("s7", "Samsung Phone", "Qualcomm830 processor");
console.log(s7);

//# sourceMappingURL=demonex01.js.map
