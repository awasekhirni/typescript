"use strict";
var ProductImpl = (function () {
    function ProductImpl(id, name, description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }
    ProductImpl.prototype.checkInventory = function () {
        return 200;
    };
    ProductImpl.prototype.updateInventory = function (delta) {
        delta = 185;
        console.log(delta);
    };
    return ProductImpl;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = ProductImpl;

//# sourceMappingURL=productimpl.js.map
