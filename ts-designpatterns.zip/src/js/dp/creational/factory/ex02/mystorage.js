"use strict";
var MyStorage = (function () {
    function MyStorage() {
    }
    MyStorage.prototype.put = function (key, value) {
        console.log("putkey");
    };
    MyStorage.prototype.get = function (key) {
        console.log("getkey");
        return "getkey";
    };
    return MyStorage;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = MyStorage;

//# sourceMappingURL=mystorage.js.map
