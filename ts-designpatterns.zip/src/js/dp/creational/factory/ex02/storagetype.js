"use strict";
var StorageType;
(function (StorageType) {
    StorageType[StorageType["Redis"] = 0] = "Redis";
    StorageType[StorageType["InMemory"] = 1] = "InMemory";
    StorageType[StorageType["CouchBase"] = 2] = "CouchBase";
    StorageType[StorageType["MongoDB"] = 3] = "MongoDB";
})(StorageType || (StorageType = {}));
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = StorageType;

//# sourceMappingURL=storagetype.js.map
