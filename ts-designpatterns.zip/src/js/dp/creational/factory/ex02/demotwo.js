"use strict";
var mystorage_1 = require('./mystorage');
var redis = new mystorage_1.default();

//# sourceMappingURL=demotwo.js.map
