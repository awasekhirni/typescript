"use strict";
var WoodPiece = (function () {
    function WoodPiece() {
        this.id = "";
    }
    return WoodPiece;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = WoodPiece;

//# sourceMappingURL=woodpiece.js.map
