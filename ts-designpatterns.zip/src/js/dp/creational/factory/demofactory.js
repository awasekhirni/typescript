"use strict";
var WoodFactory = (function () {
    function WoodFactory() {
    }
    return WoodFactory;
}());

//# sourceMappingURL=demofactory.js.map
