"use strict";
var ColumnPiece = (function () {
    function ColumnPiece() {
    }
    return ColumnPiece;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = ColumnPiece;

//# sourceMappingURL=columnpiece.js.map
