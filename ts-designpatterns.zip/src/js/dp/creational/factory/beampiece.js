"use strict";
var BeamPiece = (function () {
    function BeamPiece() {
    }
    return BeamPiece;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = BeamPiece;

//# sourceMappingURL=beampiece.js.map
