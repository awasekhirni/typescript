"use strict";
var BuilderPattern;
(function (BuilderPattern) {
    var Car = (function () {
        function Car() {
        }
        return Car;
    }());
    BuilderPattern.Car = Car;
    var CarBuilder = (function () {
        function CarBuilder() {
            this._car = new Car();
        }
        CarBuilder.prototype.setColor = function (color) {
            this._car.color = color;
        };
        CarBuilder.prototype.setWheels = function (count) {
            this._car.wheels = count;
        };
        CarBuilder.prototype.getResult = function () {
            return this._car;
        };
        return CarBuilder;
    }());
    BuilderPattern.CarBuilder = CarBuilder;
    var CarBuilderDirector = (function () {
        function CarBuilderDirector() {
        }
        CarBuilderDirector.buildmyCar = function () {
            var carBuilder = new CarBuilder();
            carBuilder.setColor('Sky Blue');
            carBuilder.setWheels(4);
            return carBuilder.getResult();
        };
        return CarBuilderDirector;
    }());
    BuilderPattern.CarBuilderDirector = CarBuilderDirector;
})(BuilderPattern = exports.BuilderPattern || (exports.BuilderPattern = {}));

//# sourceMappingURL=bp.js.map
