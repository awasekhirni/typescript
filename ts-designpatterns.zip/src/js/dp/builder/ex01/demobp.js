"use strict";
var bp = require('./bp');
var car = bp.BuilderPattern.CarBuilderDirector.buildmyCar();
console.log(car);

//# sourceMappingURL=demobp.js.map
