"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Two;
(function (Two) {
    var Part = (function () {
        function Part() {
        }
        return Part;
    }());
    Two.Part = Part;
    var Mould = (function (_super) {
        __extends(Mould, _super);
        function Mould(mouldId, mouldName, partId, partName, partDesc, partMaterial) {
            _super.call(this);
            this.mouldId = mouldId;
            this.mouldName = mouldName;
        }
        Mould.prototype.describe = function () {
            return "describe";
        };
        Mould.prototype.buildMould = function (mouldId, mouldName, partId, partName, partDesc, partMaterial) {
            console.log('describe');
            return "the " + mouldId + " and " + mouldName + " has the following parts " + partId + "," + partName + " ";
        };
        return Mould;
    }(Part));
    Two.Mould = Mould;
    var Machine = (function () {
        function Machine(machineId, machineName, mould) {
        }
        return Machine;
    }());
    Two.Machine = Machine;
})(Two = exports.Two || (exports.Two = {}));

//# sourceMappingURL=partbuilder.js.map
