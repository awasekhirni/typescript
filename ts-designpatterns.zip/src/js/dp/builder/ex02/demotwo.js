"use strict";
var bp = require('./partbuilder');
var mouldone = new bp.Two.Mould(101, "memory", 1001, "mmc card", "storage", "plastic");
var phone = new bp.Two.Machine(1, "phone", mouldone);
var camera = new bp.Two.Machine(2, "camera", mouldone);
console.log(phone);
console.log(camera);

//# sourceMappingURL=demotwo.js.map
