"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var programmer_1 = require('./programmer');
var Geek = (function (_super) {
    __extends(Geek, _super);
    function Geek(name) {
        _super.call(this, name);
    }
    Geek.prototype.empower = function (skill) {
        console.log("I got empowered with coding skills in " + this.skill);
    };
    return Geek;
}(programmer_1.default));
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Geek;

//# sourceMappingURL=geek.js.map
