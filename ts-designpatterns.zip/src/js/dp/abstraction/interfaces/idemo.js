"use strict";
var coder_1 = require('./coder');
var geekCoder = new coder_1.default("Syed Awase");

//# sourceMappingURL=idemo.js.map
