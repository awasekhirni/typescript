"use strict";
var Nerd = (function () {
    function Nerd(name) {
        this.readonly = name;
        this.name = name;
    }
    return Nerd;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Nerd;

//# sourceMappingURL=nerd.js.map
