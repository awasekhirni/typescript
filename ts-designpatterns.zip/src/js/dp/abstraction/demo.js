"use strict";
var geek_1 = require('./geek');
var syed = new geek_1.default("Syed Awase");
syed.empower('TypeScript');

//# sourceMappingURL=demo.js.map
