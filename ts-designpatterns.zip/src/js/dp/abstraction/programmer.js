"use strict";
//abstraction: a class can specify how an inherited class 
//should implement the class itself, including any abstract methods specified.
var Programmer = (function () {
    function Programmer(progName) {
        this.readonly = progName;
        this.progName = progName;
    }
    return Programmer;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Programmer;

//# sourceMappingURL=programmer.js.map
