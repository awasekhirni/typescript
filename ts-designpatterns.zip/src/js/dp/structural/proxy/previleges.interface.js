"use strict";

//# sourceMappingURL=previleges.interface.js.map
