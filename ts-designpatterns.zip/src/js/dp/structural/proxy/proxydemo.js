"use strict";
var proxymanager_1 = require('./proxymanager');
var asstMgr = new proxymanager_1.ProxyManager();
asstMgr.revokePrevileges(12);
asstMgr.DelegateTasks(12);

//# sourceMappingURL=proxydemo.js.map
