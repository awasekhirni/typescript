"use strict";
var manager_1 = require('./manager');
var ProxyManager = (function () {
    function ProxyManager() {
        this._viceManager = new manager_1.Manager();
    }
    ProxyManager.prototype.accessRecords = function (employeeId) {
        console.log("employeeId has previleges to access records");
    };
    ProxyManager.prototype.reviewRatings = function (employeeId) {
        console.log("Employee has previleges to access reviewRatings of the employees");
    };
    ProxyManager.prototype.salaryInfo = function (employeeId) {
        console.log("Employee has previleges to access SalaryInfo of the employees");
    };
    ProxyManager.prototype.grantPrevileges = function (employeeId) {
        console.log("Employee has previleges to grant Previleges to the employees");
    };
    ProxyManager.prototype.revokePrevileges = function (employeeId) {
        console.log("Employee has previleges to revoke Previleges to the employees");
    };
    ProxyManager.prototype.DelegateTasks = function (employeeId) {
        console.log("Delegate task to specific employee");
    };
    return ProxyManager;
}());
exports.ProxyManager = ProxyManager;

//# sourceMappingURL=proxymanager.js.map
