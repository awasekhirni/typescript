"use strict";
var Manager = (function () {
    function Manager() {
    }
    Manager.prototype.accessRecords = function (employeeId) {
        console.log("employeeId has previleges to access records");
    };
    Manager.prototype.reviewRatings = function (employeeId) {
        console.log("Employee has previleges to access reviewRatings of the employees");
    };
    Manager.prototype.salaryInfo = function (employeeId) {
        console.log("Employee has previleges to access SalaryInfo of the employees");
    };
    Manager.prototype.grantPrevileges = function (employeeId) {
        console.log("Employee has previleges to grant Previleges to the employees");
    };
    return Manager;
}());
exports.Manager = Manager;

//# sourceMappingURL=manager.js.map
