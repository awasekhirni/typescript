"use strict";
(function (Style) {
    Style[Style["Block"] = 0] = "Block";
    Style[Style["Inline"] = 1] = "Inline";
})(exports.Style || (exports.Style = {}));
var Style = exports.Style;

//# sourceMappingURL=style.js.map
