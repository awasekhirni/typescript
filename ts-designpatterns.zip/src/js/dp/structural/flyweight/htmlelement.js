"use strict";
var writerfactory_1 = require('./writerfactory');
var HTMLElement = (function () {
    function HTMLElement(style, color) {
        this.writer = writerfactory_1.WriterFactory.getWriter(style, color);
    }
    Object.defineProperty(HTMLElement.prototype, "content", {
        get: function () {
            return this._content;
        },
        set: function (value) {
            this._content = value;
        },
        enumerable: true,
        configurable: true
    });
    HTMLElement.prototype.write = function () {
        this.writer.write(this.content);
    };
    return HTMLElement;
}());
exports.HTMLElement = HTMLElement;

//# sourceMappingURL=htmlelement.js.map
