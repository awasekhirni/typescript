"use strict";
(function (Color) {
    Color[Color["Red"] = 0] = "Red";
    Color[Color["Green"] = 1] = "Green";
    Color[Color["Blue"] = 2] = "Blue";
    Color[Color["Violet"] = 3] = "Violet";
})(exports.Color || (exports.Color = {}));
var Color = exports.Color;

//# sourceMappingURL=color.js.map
