"use strict";
var htmlelement_1 = require('./htmlelement');
for (var i = 0; i < 100; i++) {
    var style = Math.floor(Math.random() * 2);
    var color = Math.floor(Math.random() * 3);
    var element = new htmlelement_1.HTMLElement(style, color);
    element.content = "This element uses a flyweight for rendering!";
    element.write();
}

//# sourceMappingURL=demofw.js.map
