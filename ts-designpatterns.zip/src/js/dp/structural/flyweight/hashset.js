"use strict";
var HashSet = (function () {
    function HashSet() {
        this.keys = {};
        this.values = [];
    }
    HashSet.prototype.Add = function (key) {
        if (!this.keys[key]) {
            this.values.push(key);
            this.keys[key] = key;
        }
    };
    HashSet.prototype.GetValues = function () {
        // slicing the array will return it by value so users cannot accidentally
        // start playing around with your array
        return this.values.slice();
    };
    return HashSet;
}());
exports.HashSet = HashSet;

//# sourceMappingURL=hashset.js.map
