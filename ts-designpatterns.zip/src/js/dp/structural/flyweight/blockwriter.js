"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var writer_1 = require('./writer');
var BlockWriter = (function (_super) {
    __extends(BlockWriter, _super);
    function BlockWriter(color) {
        _super.call(this, "div", color);
    }
    return BlockWriter;
}(writer_1.Writer));
exports.BlockWriter = BlockWriter;

//# sourceMappingURL=blockwriter.js.map
