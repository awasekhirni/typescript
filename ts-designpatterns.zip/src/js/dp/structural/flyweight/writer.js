"use strict";
var color_1 = require("./color");
var Writer = (function () {
    function Writer(tagName, color) {
        this.tagName = tagName;
        this.color = color;
    }
    Writer.prototype.write = function (content) {
        console.log("<" + this.tagName + "style='color:'" + color_1.Color[this.color] + "'>" + content + "");
    };
    return Writer;
}());
exports.Writer = Writer;

//# sourceMappingURL=writer.js.map
