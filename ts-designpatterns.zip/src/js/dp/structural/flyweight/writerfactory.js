"use strict";
var style_1 = require("./style");
var blockwriter_1 = require("./blockwriter");
var inlinewriter_1 = require("./inlinewriter");
var WriterFactory = (function () {
    function WriterFactory() {
    }
    WriterFactory.getWriter = function (style, color) {
        var key = style.toString() + color.toString();
        if (!this._elements[key]) {
            switch (style) {
                case style_1.Style.Block:
                    this._elements[key] = new blockwriter_1.BlockWriter(color);
                    break;
                case style_1.Style.Inline:
                    this._elements[key] = new inlinewriter_1.InlineWriter(color);
                    break;
            }
        }
        var retVal = this._elements[key];
        return retVal;
    };
    WriterFactory._elements = {};
    return WriterFactory;
}());
exports.WriterFactory = WriterFactory;

//# sourceMappingURL=writerfactory.js.map
