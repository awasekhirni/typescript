"use strict";
var PersonDecorator = (function () {
    function PersonDecorator(person) {
        this.decoratedPerson = person;
    }
    Object.defineProperty(PersonDecorator.prototype, "name", {
        get: function () {
            return this.decoratedPerson.name;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PersonDecorator.prototype, "age", {
        get: function () {
            return this.decoratedPerson.age;
        },
        enumerable: true,
        configurable: true
    });
    PersonDecorator.prototype.identify = function () {
        return this.decoratedPerson.identify();
    };
    return PersonDecorator;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = PersonDecorator;

//# sourceMappingURL=persondecorator.js.map
