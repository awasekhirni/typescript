"use strict";
var SimplePerson = (function () {
    function SimplePerson() {
    }
    SimplePerson.prototype.identify = function () {
        console.log(this.name + " age " + this.age);
    };
    return SimplePerson;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = SimplePerson;

//# sourceMappingURL=simpleperson.js.map
