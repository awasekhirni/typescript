"use strict";
var simpleperson_1 = require('./simpleperson');
var student_1 = require('./student');
var Dad = new simpleperson_1.default();
Dad.name = "Syed Awase";
Dad.age = 38;
var Mom = new simpleperson_1.default();
Mom = new student_1.default(Mom);
Mom.name = "SKhan";
Mom.age = 32;
Mom.school = "Pune University";

//# sourceMappingURL=demoone.js.map
