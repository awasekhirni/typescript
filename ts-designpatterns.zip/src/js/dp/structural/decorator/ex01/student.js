"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var persondecorator_1 = require('./persondecorator');
var Student = (function (_super) {
    __extends(Student, _super);
    function Student() {
        _super.apply(this, arguments);
    }
    Student.prototype.logSchool = function () {
        console.log(this.school);
    };
    return Student;
}(persondecorator_1.default));
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Student;

//# sourceMappingURL=student.js.map
