"use strict";
var ElectricalSockets;
(function (ElectricalSockets) {
    var GermanSocket = (function () {
        function GermanSocket() {
        }
        GermanSocket.prototype.giveElectricity = function () {
            return true;
        };
        return GermanSocket;
    }());
    ElectricalSockets.GermanSocket = GermanSocket;
    var BritishSocket = (function () {
        function BritishSocket() {
        }
        BritishSocket.prototype.provideElectricity = function () {
            return true;
        };
        return BritishSocket;
    }());
    ElectricalSockets.BritishSocket = BritishSocket;
    var GermanToBritishAdapter = (function () {
        function GermanToBritishAdapter() {
        }
        GermanToBritishAdapter.prototype.GermantoBritishConnector = function (pg) {
            return true;
        };
        GermanToBritishAdapter.prototype.provideElectricity = function () {
            return true;
        };
        return GermanToBritishAdapter;
    }());
    ElectricalSockets.GermanToBritishAdapter = GermanToBritishAdapter;
})(ElectricalSockets = exports.ElectricalSockets || (exports.ElectricalSockets = {}));

//# sourceMappingURL=electricalsockets.js.map
