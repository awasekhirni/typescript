"use strict";
var es = require('./electricalsockets');
var pg = new es.ElectricalSockets.GermanSocket();
var uksocket = new es.ElectricalSockets.BritishSocket();
var btogAdapter = new es.ElectricalSockets.GermanToBritishAdapter();
btogAdapter.GermantoBritishConnector(pg);

//# sourceMappingURL=demo.js.map
