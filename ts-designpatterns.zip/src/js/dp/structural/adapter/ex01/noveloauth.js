"use strict";
var OAuth = (function () {
    function OAuth() {
    }
    OAuth.prototype.twofactorAuth = function (login, pwd, mobilePIN) {
        return true;
    };
    OAuth.prototype.tokenbasedAuth = function (login, pwd, token) {
        return true;
    };
    OAuth.prototype.verifyEmail = function (email, pwd) {
        return true;
    };
    OAuth.prototype.verifyPassword = function (login, pwd) {
        return true;
    };
    return OAuth;
}());
exports.OAuth = OAuth;
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = OAuth;

//# sourceMappingURL=noveloauth.js.map
