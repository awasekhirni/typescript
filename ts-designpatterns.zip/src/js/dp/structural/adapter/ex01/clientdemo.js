"use strict";
var authsystem_1 = require('./authsystem');
var client = (function () {
    function client() {
    }
    client.prototype.loginProcess = function (login, password, email, mobilePIN, token) {
        if (mobilePIN || token) {
            var $newLoginSystem = new authsystem_1.default();
        }
        else {
            var $oldways = new authsystem_1.default();
        }
    };
    return client;
}());

//# sourceMappingURL=clientdemo.js.map
