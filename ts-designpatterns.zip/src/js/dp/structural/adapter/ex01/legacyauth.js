"use strict";
var LegacyAuthentication = (function () {
    function LegacyAuthentication() {
    }
    LegacyAuthentication.prototype.verifyEmail = function () {
        return true;
    };
    LegacyAuthentication.prototype.verifyPassword = function () {
        return true;
    };
    return LegacyAuthentication;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = LegacyAuthentication;

//# sourceMappingURL=legacyauth.js.map
