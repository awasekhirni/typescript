"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var noveloauth_1 = require('./noveloauth');
var AuthSystem = (function (_super) {
    __extends(AuthSystem, _super);
    function AuthSystem() {
        _super.apply(this, arguments);
    }
    AuthSystem.prototype.oldwayAuthentication = function (legacyAuthentication) {
        this.legacy = legacyAuthentication;
    };
    AuthSystem.prototype.nuovusAuthentication = function (oAuth) {
        this.oAuth = oAuth;
    };
    return AuthSystem;
}(noveloauth_1.default));
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = AuthSystem;

//# sourceMappingURL=authsystem.js.map
