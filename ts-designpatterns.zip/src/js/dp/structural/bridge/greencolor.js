"use strict";
var GreenColor = (function () {
    function GreenColor() {
    }
    GreenColor.prototype.applyColor = function () {
        console.log("green");
    };
    return GreenColor;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = GreenColor;

//# sourceMappingURL=greencolor.js.map
