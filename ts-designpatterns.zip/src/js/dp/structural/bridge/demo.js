"use strict";
var triangle_1 = require('./triangle');
var pentagon_1 = require('./pentagon');
var redcolor_1 = require('./redcolor');
var greencolor_1 = require('./greencolor');
var st = new triangle_1.default(new redcolor_1.default());
var pt = new pentagon_1.default(new greencolor_1.default());

//# sourceMappingURL=demo.js.map
