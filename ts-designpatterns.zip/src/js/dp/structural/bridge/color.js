"use strict";

//# sourceMappingURL=color.js.map
