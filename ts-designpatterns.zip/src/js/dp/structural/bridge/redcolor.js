"use strict";
var RedColor = (function () {
    function RedColor() {
    }
    RedColor.prototype.applyColor = function () {
        console.log("green");
    };
    return RedColor;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = RedColor;

//# sourceMappingURL=redcolor.js.map
