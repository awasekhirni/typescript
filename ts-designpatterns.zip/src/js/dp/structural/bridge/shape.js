"use strict";
var Shape = (function () {
    function Shape(clr) {
    }
    return Shape;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Shape;

//# sourceMappingURL=shape.js.map
