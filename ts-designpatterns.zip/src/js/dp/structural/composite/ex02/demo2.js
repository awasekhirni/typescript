"use strict";
var composite_1 = require('./composite');
var leaf_1 = require('./leaf');
var leafone = new leaf_1.default("1");
var leaftwo = new leaf_1.default("2");
var leafthree = new leaf_1.default("3");
var compone = new composite_1.default("CompositeOne");
var comptwo = new composite_1.default("Compositetwo");
compone.add(leafone);
compone.add(leaftwo);
compone.add(leafthree);
compone.operation();

//# sourceMappingURL=demo2.js.map
