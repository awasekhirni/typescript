"use strict";
var Leaf = (function () {
    function Leaf(s) {
        this.s = s;
    }
    Leaf.prototype.operation = function () {
        console.log("operation of composite " + this.s + " is invoked!");
    };
    return Leaf;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Leaf;

//# sourceMappingURL=leaf.js.map
