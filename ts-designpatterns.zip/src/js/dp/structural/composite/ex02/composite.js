"use strict";
var Composite = (function () {
    function Composite(s) {
        this.list = [];
        this.s = s;
    }
    Composite.prototype.operation = function () {
        console.log("operation of composite " + this.s + " is invoked!");
        for (var i = 0; i < this.list.length; i += 1) {
            this.list[i].operation();
        }
    };
    Composite.prototype.add = function (c) {
        this.list.push(c);
    };
    Composite.prototype.remove = function (i) {
        if (this.list.length <= 1) {
            throw new Error("index out of bounds");
        }
        ;
        this.list.splice(i, i === 0 ? 1 : i);
    };
    return Composite;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Composite;

//# sourceMappingURL=composite.js.map
