"use strict";

//# sourceMappingURL=icomponent.js.map
