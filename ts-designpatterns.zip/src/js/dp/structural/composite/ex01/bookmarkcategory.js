"use strict";
var BookmarkCategory = (function () {
    function BookmarkCategory(name) {
        this.name = name;
        this.components = new Array();
    }
    BookmarkCategory.prototype.getName = function () {
        return this.name;
    };
    ;
    BookmarkCategory.prototype.getSize = function () {
        var result = this.name.length;
        for (var i = 0; i < this.components.length; i += 1) {
            result += this.components[i].getSize();
        }
        return result;
    };
    ;
    BookmarkCategory.prototype.getCount = function () {
        var result = 1;
        for (var i = 0; i < this.components.length; i += 1) {
            result += this.components[i].getCount();
        }
        return result;
    };
    ;
    BookmarkCategory.prototype.getType = function () {
        return 2;
    };
    ;
    BookmarkCategory.prototype.getData = function () {
        return "";
    };
    ;
    BookmarkCategory.prototype.AddBookmarkEntry = function (name, url) {
        this.AddComponent(new BookmarkEntry(name, url));
    };
    /**
      Add a component to the composition
    */
    BookmarkCategory.prototype.AddComponent = function (component) {
        this.components.push(component);
    };
    /**
      Sort so that the categories appear on top
    */
    BookmarkCategory.prototype.SortComponents = function () {
        this.components.sort(function (a, b) {
            if (a.getType() === b.getType()) {
                if (a.getName() < b.getName()) {
                    return -1;
                }
                else if (a.getName() > b.getName()) {
                    return 1;
                }
                return 0;
            }
            return (b.getType() - a.getType());
        });
    };
    /**
      Return the list of components in this composition
    */
    BookmarkCategory.prototype.getComponents = function () {
        return this.components;
    };
    return BookmarkCategory;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = BookmarkCategory;

//# sourceMappingURL=bookmarkcategory.js.map
