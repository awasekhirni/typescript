"use strict";

//# sourceMappingURL=bookmarkcomponent.js.map
