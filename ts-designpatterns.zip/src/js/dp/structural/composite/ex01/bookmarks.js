"use strict";
var bookmarkcategory_1 = require('./bookmarkcategory');
/**
  A collection keeping track of the root of the category / entry tree.
*/
var Bookmarks = (function () {
    function Bookmarks() {
        this.root = new bookmarkcategory_1.default("root");
    }
    /**
      Add any object to the specified category following a specific syntax
      of name: url or name: children
    */
    Bookmarks.prototype.addToCategory = function (input, category) {
        for (var i in input) {
            if (input.hasOwnProperty(i)) {
                var value = input[i];
                if (typeof value === "string") {
                    category.AddBookmarkEntry(i, value);
                }
                else if (typeof value === "object") {
                    var newCategory = new bookmarkcategory_1.default(i);
                    this.addToCategory(value, newCategory);
                    category.AddComponent(newCategory);
                }
                else {
                    throw new Error("What are thooooose?");
                }
            }
        }
        category.SortComponents();
    };
    /**
      Add any object to the root category following a specific syntax
      of name: url or name: children
    */
    Bookmarks.prototype.LoadData = function (input) {
        this.addToCategory(input, this.root);
    };
    return Bookmarks;
}());

//# sourceMappingURL=bookmarks.js.map
