"use strict";
var BookmarkEntry = (function () {
    function BookmarkEntry(name, url) {
        this.name = name;
        this.url = url;
        this.name = name;
        this.url = url;
    }
    BookmarkEntry.prototype.getName = function () {
        return this.name;
    };
    ;
    BookmarkEntry.prototype.getSize = function () {
        return this.name.length + this.url.length;
    };
    ;
    BookmarkEntry.prototype.getCount = function () {
        return 1;
    };
    ;
    BookmarkEntry.prototype.getType = function () {
        return 1;
    };
    ;
    BookmarkEntry.prototype.getData = function () {
        return this.url;
    };
    ;
    return BookmarkEntry;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = BookmarkEntry;

//# sourceMappingURL=bookmarkentry.js.map
