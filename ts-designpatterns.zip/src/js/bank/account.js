"use strict";
var Account = (function () {
    function Account(accountid, initialBalance) {
        if (initialBalance === void 0) { initialBalance = 0; }
        if (!accountid) {
            throw new Error("id must be provided");
        }
        if (initialBalance < 0) {
            throw new Error("initialBalance must be above zero");
        }
        this.accountid = accountid;
        this.balance = initialBalance;
    }
    Account.prototype.isInteger = function (value) {
        return typeof value === "number" && isFinite(value) && Math.floor(value) === value;
    };
    return Account;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Account;

//# sourceMappingURL=account.js.map
