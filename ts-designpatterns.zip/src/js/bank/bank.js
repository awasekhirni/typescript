"use strict";
var account_1 = require('./account');
var Bank = (function () {
    function Bank() {
        this.accounts = new Array();
    }
    Bank.prototype.openAccount = function (accountid, initialBalance) {
        if (initialBalance === void 0) { initialBalance = 0; }
        var account = this.getAccount(accountid, false);
        if (account) {
            throw new Error("Account Exists");
        }
        if (initialBalance < 0) {
            throw new Error("the initial balance is low");
        }
        Bank.accounts.push(new account_1.default(accountid, initialBalance));
    };
    return Bank;
}());

//# sourceMappingURL=bank.js.map
