"use strict";
var Vehicle = (function () {
    function Vehicle(mpg, fuel) {
        if (mpg === void 0) { mpg = 12; }
        if (fuel === void 0) { fuel = 10; }
        this._moving = false;
        this._milespergalon = mpg;
        this._avlblgas = fuel;
        this._currentMiles = 0;
    }
    Vehicle.prototype.shiftGear = function () {
        console.log(this.name, "Shifted the car gear");
    };
    Vehicle.prototype.applyBrakes = function () {
        console.log(this.name, "applied brakes");
    };
    Vehicle.prototype.drive = function () {
        console.log(this.name, "drive the car");
    };
    Vehicle.prototype.getGasMileage = function () {
        return this._avlblgas;
    };
    Vehicle.prototype.setGasMileage = function (mpg) {
        this._avlblgas = mpg;
    };
    return Vehicle;
}());
exports.Vehicle = Vehicle;

//# sourceMappingURL=vehicle.js.map
