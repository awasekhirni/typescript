"use strict";
var Radio = (function () {
    function Radio() {
        this.isTrackPlaying = false;
    }
    Radio.prototype.playSelection = function (preset) {
        this.isTrackPlaying = true;
    };
    Radio.prototype.turnOff = function () {
        this.isTrackPlaying = false;
    };
    return Radio;
}());
exports.Radio = Radio;

//# sourceMappingURL=radio.js.map
