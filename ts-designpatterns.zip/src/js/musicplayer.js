"use strict";
var MusicPlayer = (function () {
    function MusicPlayer() {
        this.isTrackPlaying = false;
    }
    MusicPlayer.prototype.playSelection = function (preset) {
        this.isTrackPlaying = true;
    };
    MusicPlayer.prototype.turnOff = function () {
        this.isTrackPlaying = false;
    };
    MusicPlayer.prototype.eject = function () {
        console.log("Please eject the CD player");
    };
    return MusicPlayer;
}());
exports.MusicPlayer = MusicPlayer;

//# sourceMappingURL=musicplayer.js.map
