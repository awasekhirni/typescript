class Customer {
    name:string;
    type:string;
    id:number;
    email:string;
    phone:number;
    constructor(name:string,type:string,id:number,email:string,phone:number){
        this.name=name;
        this.type=type;
        this.id=id;
        this.email=email;
        this.phone=phone;
    }

    getName(){
        return this.name;
    }
}