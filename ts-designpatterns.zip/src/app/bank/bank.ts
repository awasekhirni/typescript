import Account from './account';

class Bank{
    public static accountUpdates;
    public accounts:Account[]= new Array<Account>();
    
    constructor(){

    }


    public openAccount(accountid:string,initialBalance=0):any{
        let account= this.getAccount(accountid, false);
        if(account){
            throw new Error("Account Exists");
        }
        if(initialBalance<0){
            throw new Error("the initial balance is low");
        }
        Bank.accounts.push(new Account(accountid,initialBalance));
    }
}