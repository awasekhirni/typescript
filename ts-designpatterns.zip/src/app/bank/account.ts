class Account{
    public accountid:string;
    public balance:number;
    public accountname:string;
    constructor(accountid:string, initialBalance=0){
        if(!accountid){
            throw new Error("id must be provided");
        }

        if(initialBalance<0){
            throw new Error("initialBalance must be above zero");
        }
       
        this.accountid=accountid;
        this.balance=initialBalance;
    }


    private isInteger(value:number){
        return typeof value==="number" && isFinite(value) && Math.floor(value)===value;
    }
}

export default Account;