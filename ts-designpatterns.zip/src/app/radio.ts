import { IAudible } from "./iaudible";

export class Radio implements IAudible {
    isTrackPlaying: boolean;
    turnOn: void;
    constructor(){
        this.isTrackPlaying=false;
    }
    playSelection(preset: number): void {
        this.isTrackPlaying=true;
    }
    turnOff(): void {
        this.isTrackPlaying=false;
    }

}