//client for configurationmgr
import * as cm from './configmgr';
console.log(cm.config.getMaxAllow);
console.log(cm.config.getMaxConcurrentDevices());
