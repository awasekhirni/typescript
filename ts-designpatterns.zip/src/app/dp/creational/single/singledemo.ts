import Bachelor from './singletonex';
//const aicy=new Bachelor();
const aicy= Bachelor.getInstance();
console.log(aicy.age);
console.log(aicy.age=25);
const rayyan=Bachelor.getInstance();
console.log(rayyan===aicy);