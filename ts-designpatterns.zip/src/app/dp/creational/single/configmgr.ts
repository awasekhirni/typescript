//configmgr.ts =>configuration manager
//npm install node-env-run --save-dev
export module config{
    const Max_Connections_allowed = 10;
    const DEVICES_PER_CONNECTION = 25;
     export function getMaxAllow(): number {
        return process.env[Max_Connections_allowed] as number;
    }
    export function getMaxConcurrentDevices(): number {
        return DEVICES_PER_CONNECTION * getMaxAllow();
    }
}
