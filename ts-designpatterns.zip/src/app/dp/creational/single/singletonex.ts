class Bachelor {
        private static instance: Bachelor;
        private _age: number;
        private constructor() { }
        static getInstance() {
                if (!Bachelor.instance) {
                        Bachelor.instance = new Bachelor();
                        Bachelor.instance._age = 16;
                }
                return Bachelor.instance;
        }
        get age():number{
                return this._age;
        }
        set age(myage){
                this._age=myage;
        }
        increaseAge():number{
                return this._age+=1;
        }
        decreaseAge():number{
                return this._age-=1;
        }
}
export default Bachelor;