export namespace BrickPrototype{

    export interface Brick{
        clone():Brick;
        toString():string;
    }

    export class CementBrick implements Brick{
        clone(): Brick {
            return new CementBrick();
        }
        toString(): string {
            return "this is a CementBrick";
        }

    }

export class RedBrick implements Brick{
    clone(): Brick {
        return new RedBrick();
    }
    toString(): string {
        return "this is a redbrick";
    }

}

export class Builder{
    private prototypeMap:{[s:string]:Brick}={};

    constructor(){
        this.prototypeMap['brick1']= new CementBrick();
        this.prototypeMap['brick2']= new RedBrick(); 
    }

    createOne(s:string):Brick{
        console.log(s);
        return this.prototypeMap[s].clone();
    }
}


}