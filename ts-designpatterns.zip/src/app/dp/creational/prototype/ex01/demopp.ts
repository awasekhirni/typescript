import * as bp from './brickprototype';

let test = new bp.BrickPrototype.Builder();
console.log(test);