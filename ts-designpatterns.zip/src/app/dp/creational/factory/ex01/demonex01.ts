import ProductImpl from './productimpl';
let s7= new ProductImpl("s7","Samsung Phone", "Qualcomm830 processor");
console.log(s7);