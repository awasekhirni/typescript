interface IProduct{
    id:string;
    name:string;
    description:string;
    checkInventory():number;
    updateInventory(delta:number):void;
}
export default IProduct;