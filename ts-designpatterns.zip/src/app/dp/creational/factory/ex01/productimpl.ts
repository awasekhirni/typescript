import IProduct from './iproduct';
class ProductImpl implements IProduct{
    id: string;
    name: string;
    description: string;
    checkInventory(): number {
        return 200;
    }
    updateInventory(delta: number): void {
        delta=185;
        console.log(delta);
    }
    constructor(id:string, name:string,description:string){
        this.id=id;
        this.name=name;
        this.description=description;
    }
}
export default ProductImpl;