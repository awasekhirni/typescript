import WoodPiece from './woodpiece';
class BeamPiece implements WoodPiece{
    id: string;
    isOfwoodentype: string;
    length: number;
    width: number;
    height: number;
}

export default BeamPiece;