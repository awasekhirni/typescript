import IStorage from './istorage';
class MyStorage implements IStorage{
    put(key: string, value: string) {
        console.log("putkey");
    }
    get(key: string): string {
        console.log("getkey");
        return "getkey";
    }

}

export default MyStorage;