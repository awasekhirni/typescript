import MyStorage from './mystorage';
let redis= new MyStorage();
