enum StorageType{
    Redis,
    InMemory,
    CouchBase,
    MongoDB
}

export default StorageType;