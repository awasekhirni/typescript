interface IStorage{
    put(key:string,value:string);
    get(key:string):string;
}

export default IStorage;