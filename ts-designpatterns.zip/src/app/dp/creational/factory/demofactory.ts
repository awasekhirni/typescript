import ColumnPiece from './columnpiece';
import BeamPiece from './beampiece';

class WoodFactory{

}