abstract class WoodPiece{
    id:string="";
    isOfwoodentype:string;
    length:number;
    width:number;
    height:number;  
}

export default WoodPiece;