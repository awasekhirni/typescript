import WoodPiece from './woodpiece';

class ColumnPiece implements WoodPiece{
    id: string;
    isOfwoodentype: string;
    length: number;
    width: number;
    height: number;
}

export default ColumnPiece;