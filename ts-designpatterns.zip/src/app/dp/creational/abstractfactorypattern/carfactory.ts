export namespace CarFactory{
    export interface ICar{
        engineType:String;
        seatingCapacity:Number;
        length:Number;
        width:Number;
        engineStart():Boolean;
        applyBrake():Boolean;
        accelerate():Boolean;
    }
    export interface ICarFactory{
        make:String;
        manufacture:String;
        BuildCar(carType:CarType):ICar;
    }
    export enum CarType{
        Nano=0,
        Compact=1,
        Sedan=2,
        Muv=3,
        Suv=4,
        Uv=5,
        Offroader=6,
        Pickup=7
    }

    export class TataNano implements ICar{
        engineType: String;
        seatingCapacity: Number;
        length: Number;
        width: Number;
        engineStart(): Boolean {
            return true;
        }
        applyBrake(): Boolean {
           return true;
               }
        accelerate(): Boolean {
            return true;
        }
        constructor(){
            this.engineType="small";
            this.seatingCapacity=2;
            this.length=3.2;
            this.width=3.6;
        }
    }

    export class TataBolt implements ICar{
        engineType: String="medium";
        seatingCapacity: Number=4;
        length: Number=4.8;
        width: Number=4.2;
        engineStart(): Boolean {
            return true;
        }
        applyBrake(): Boolean {
            return true;
        }
        accelerate(): Boolean {
            return true;
        }
    }

    export class TataSafari implements ICar{
        engineType: String="large";
        seatingCapacity: Number=7;
        length: Number=6.2;
        width: Number=5.2;
        engineStart(): Boolean {
            return true;
        }
        applyBrake(): Boolean {
            return true;
        }
        accelerate(): Boolean {
            return true;
        }
    }

     export class SilguriCarFactory implements ICarFactory{
        make: String="TATA";
        manufacture: String="TATA SONS";
        BuildCar(carType: CarType):ICar{
            let car:ICar=null;
            switch(carType){
                case carType.Nano:
                        car= new TataNano();
                        break;
                case carType.Compact:
                    car = new TataBolt();
                    break;
                case carType.Suv:
                    car = new TataSafari();
                    break;
            }
            return car;
        }
    }


    export namespace Demo {
        export function display() {

            let mynano = new SilguriCarFactory();
            mynano.BuildCar(0);
            mynano.BuildCar(1);
            mynano.BuildCar(4);
        }
    }
    

}