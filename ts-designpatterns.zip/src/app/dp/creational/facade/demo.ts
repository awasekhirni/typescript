import PreLoanChecks from './preloanchecks';

const loanReq:PreLoanChecks= new PreLoanChecks(2428812889128913); 
loanReq.takeLoan();