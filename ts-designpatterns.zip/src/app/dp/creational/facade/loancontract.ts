// facade pattern: used when there are multiple subsystem(multiple APIs)available for the application 
// loan application to a bank checks for credit rating, fraud systems, other loan information. 


class LoanContract{
    private loanEndDate:Date;
    constructor(endDate:Date){
        this.loanEndDate=endDate;
    }

    checkAnyloans(date:Date):any{
        if(date<this.loanEndDate){
            return true;
        }else{
            return false;
        }
    }
}


export default LoanContract;