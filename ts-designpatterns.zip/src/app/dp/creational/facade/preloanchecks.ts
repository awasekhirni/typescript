import LoanContract from './loancontract';
import CompanyFunds from './companyfunds';

class PreLoanChecks{
    private contract:LoanContract=new LoanContract(new Date(new Date().setDate(new Date().getDate()+10)));
    private funds:CompanyFunds=new CompanyFunds(2000000000);

    private userContract:Date;
    private loanAmount:number; 

    constructor(loanAmount:number){
        this.userContract=new Date();
        this.loanAmount=loanAmount;
    }

    takeLoan(): void {
        if (this.contract.checkAnyloans(this.userContract)) {
            console.log('User has active loan');
        } else {
            console.log('User has no active loan');
            if (!this.funds.checkFunds(this.loanAmount)) {
                console.log('the loan amount req is high');
            } else {
                console.log('user can be given loan');
            }
        }
    }

}


export default PreLoanChecks;