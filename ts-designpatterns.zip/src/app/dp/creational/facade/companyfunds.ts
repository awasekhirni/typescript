class CompanyFunds{

    private fundBalance:number;
    constructor(ttlamount:number){
        this.fundBalance=ttlamount;
    }

    checkFunds(transactionFee:number):boolean{
        if(transactionFee<this.fundBalance){
            return true;
        }
    }
}

export default CompanyFunds;