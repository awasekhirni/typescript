import * as bp from './partbuilder'; 

let mouldone= new bp.Two.Mould(101,"memory", 1001, "mmc card","storage", "plastic");
let phone = new bp.Two.Machine(1,"phone", mouldone);
let camera = new bp.Two.Machine(2, "camera", mouldone);
console.log(phone);
console.log(camera);