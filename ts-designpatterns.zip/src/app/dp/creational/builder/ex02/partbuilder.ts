export namespace Two{

    export abstract class Part{
        public partId:number;
        public partName:string;
        public partDesc:string;
        public partMaterial:string;
        public abstract describe():string;
    }


    export class  Mould extends Part{
        public mouldId:number;
        public mouldName:string;
        constructor(mouldId:number, mouldName:string, partId:number, partName:string,partDesc:string, partMaterial:string){
            super();
            this.mouldId=mouldId;
            this.mouldName=mouldName;
        }

        public describe():string{
            return"describe";
        }
        public buildMould(mouldId,mouldName,partId,partName,partDesc,partMaterial): string {
            console.log('describe');
            return `the ${mouldId} and ${mouldName} has the following parts ${partId},${partName} `;
        }

    }

    export class Machine {
        public machineId:number;
        public machineName:string;
        public mould:Mould;
        constructor(machineId:number, machineName:string, mould:Mould){
        }
    }
}