import * as bp from './bp';

let car = bp.BuilderPattern.CarBuilderDirector.buildmyCar();
console.log(car);
