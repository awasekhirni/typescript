export namespace BuilderPattern{

    export class Car{
        wheels:Number;
        color:String;
    }

    export interface ICarBuilder{
        setColor(color:string):void;
        setWheels(count:number):void;
        getResult():Car;
    }

    export class CarBuilder implements ICarBuilder{
        private _car:Car;
        constructor(){
            this._car=new Car();
        }
        setColor(color: string): void {
            this._car.color=color;
        }
        setWheels(count: number): void {
            this._car.wheels=count;
        }
        getResult(): Car {
            return this._car;
        }

    }

    
    export class CarBuilderDirector {
        static buildmyCar(): Car {
            let carBuilder = new CarBuilder();
            carBuilder.setColor('Sky Blue');
            carBuilder.setWheels(4);
            return carBuilder.getResult();
        }
    }

    

}