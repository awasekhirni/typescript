import Programmer from './programmer';
import Geek from './geek';
const syed = new Geek("Syed Awase");
syed.empower('TypeScript');
