import IProgrammer from './iprogrammer';
abstract class Nerd implements IProgrammer{
    readonly name: string;
   public skill: string;
    constructor(name:string){
        this.name=name;
    }
    abstract empower(skill: string): void;

}
export default Nerd;

