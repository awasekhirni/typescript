interface IProgrammer{
    name:string;
    skill:string;
    empower(skill:string):void;
}
export default IProgrammer;
