import Nerd from './nerd';
class Coder extends Nerd{
    constructor(name:string){
        super(name);
    }
    empower(skill: string): void {
        console.log(`${this.name} is super coder`);
    }
}
export default Coder;