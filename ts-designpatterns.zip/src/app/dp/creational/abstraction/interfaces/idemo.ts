import Coder from './coder';
import IProgrammer from './iprogrammer';
const geekCoder:IProgrammer=new Coder("Syed Awase");
