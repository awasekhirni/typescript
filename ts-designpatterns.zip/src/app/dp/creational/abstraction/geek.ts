import Programmer from './programmer';
class Geek extends Programmer{
    constructor(name:string){
        super(name);
    }
    empower(skill: string): void {
        console.log(`I got empowered with coding skills in ${this.skill}`);
    }
}
export default Geek;