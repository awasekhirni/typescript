//abstraction: a class can specify how an inherited class 
//should implement the class itself, including any abstract methods specified.
abstract class Programmer{
    readonly progName:string;
    public skill:string;
    constructor(progName:string){
        this.progName=progName;
    }
    abstract empower(skill:string):void;
}
export default Programmer;

