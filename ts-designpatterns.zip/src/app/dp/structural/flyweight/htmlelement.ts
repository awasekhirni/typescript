import { WriterFactory } from './writerfactory';
import { Style } from './style';
import { IWriter } from './iwriter';
import { Color } from './color';
export class HTMLElement{
    private writer:IWriter;
    constructor(style:Style,color:Color){
        this.writer=WriterFactory.getWriter(style,color);
    }
    private _content:string;
    public get content():string{
        return this._content;
    }

    public set content(value:string){
        this._content=value;
    }

    public write():void{
        this.writer.write(this.content);
    }
}