import { Color } from './color';
import { Writer } from './writer';
export class BlockWriter extends Writer{
    constructor(color:Color){
        super("div",color);
    }
}