export enum Style{
    Block,
    Inline
}