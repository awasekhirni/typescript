export enum Color{
    Red,
    Green,
    Blue,
    Violet
}