import { HTMLElement } from './htmlelement';

for (var i = 0; i < 100; i++) {
    var style = Math.floor(Math.random() * 2);
    var color = Math.floor(Math.random() * 3);

    var element = new HTMLElement(style, color);
    element.content = "This element uses a flyweight for rendering!";
    element.write();
}