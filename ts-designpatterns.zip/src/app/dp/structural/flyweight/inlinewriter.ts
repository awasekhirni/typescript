import { Writer } from "./writer";
import { Color } from "./color";

export class InlineWriter extends Writer {
  constructor(color: Color) {
      super("span",color);
  }
}
