export interface IHash {
    [details: string] : string;
} 

export class HashSet{
    private keys: IHash = {};
    private values: string[] = [];
  
    public Add(key: string){
      if(!this.keys[key]){
        this.values.push(key);
        this.keys[key] = key;
      }
    }
  
    public GetValues(){
      // slicing the array will return it by value so users cannot accidentally
      // start playing around with your array
      return this.values.slice();
    }
  }