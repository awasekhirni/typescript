import { Style } from "./style";
import { Color } from "./color";
import { IWriter } from "./iwriter";
import { BlockWriter } from "./blockwriter";
import { InlineWriter } from "./inlinewriter";

export class WriterFactory{
    static _elements={};
    static getWriter(style:Style,color:Color):IWriter{
        var key = style.toString() + color.toString();
            if (!this._elements[key]) {
                
                switch (style) {
                    case Style.Block:
                        this._elements[key] = new BlockWriter(color);
                        break;
                    case Style.Inline:
                        this._elements[key] = new InlineWriter(color);
                        break;
                }
            }

            var retVal = this._elements[key];
            return retVal;
    }
}