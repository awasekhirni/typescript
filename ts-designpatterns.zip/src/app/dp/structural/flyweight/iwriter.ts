export interface IWriter{
    write(content:string):void;
}