import { ProxyManager } from './proxymanager';


let asstMgr = new ProxyManager();
asstMgr.revokePrevileges(12);
asstMgr.DelegateTasks(12);