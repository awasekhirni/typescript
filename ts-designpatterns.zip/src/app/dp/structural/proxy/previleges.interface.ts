export interface IPrevileges{
    employeeId:number;
    employeeName:string;
    employeeRole:string;
    employeeRating:number;
    employeeReview:string;
    employeePrevilege:string;
    accessRecords(employeeId:number);
    reviewRatings(employeeId:number);
    salaryInfo(employeeId:number);
    grantPrevileges(employeeId:number);
}