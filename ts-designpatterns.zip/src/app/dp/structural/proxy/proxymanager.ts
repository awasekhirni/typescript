import { IPrevileges } from './previleges.interface';
import { Manager } from './manager';
export class ProxyManager implements IPrevileges{
    employeeId: number;
    employeeName: string;
    employeeRole: string;
    employeeRating: number;
    employeeReview: string;
    employeePrevilege: string;
    accessRecords(employeeId: number) {
        console.log("employeeId has previleges to access records");
    }
    reviewRatings(employeeId: number) {
        console.log("Employee has previleges to access reviewRatings of the employees");
        }
    salaryInfo(employeeId: number) {
        console.log("Employee has previleges to access SalaryInfo of the employees");
    }
    grantPrevileges(employeeId: number) {
        console.log("Employee has previleges to grant Previleges to the employees");
    }

    revokePrevileges(employeeId:number){
        console.log("Employee has previleges to revoke Previleges to the employees");
    
    }

    DelegateTasks(employeeId:number){
        console.log("Delegate task to specific employee");
    }
    private _viceManager:Manager= new Manager();
    
}