import Person from './person';

abstract class PersonDecorator implements Person{
    protected decoratedPerson:Person;

    public constructor(person:Person){
        this.decoratedPerson=person;
    }

    public get name(){
        return this.decoratedPerson.name;
    }

    public get age(){
        return this.decoratedPerson.age;
    }

    identify():void{
        return this.decoratedPerson.identify();
    }

}

export default PersonDecorator;