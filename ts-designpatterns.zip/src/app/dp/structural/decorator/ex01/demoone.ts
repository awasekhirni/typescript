import SimplePerson from './simpleperson';
import Student from './student';
import Child from './child';

let Dad = new SimplePerson();
Dad.name = "Syed Awase";
Dad.age = 38;

let Mom = new SimplePerson();
Mom = new Student(Mom);
Mom.name = "SKhan";
Mom.age = 32;
(Mom as Student).school = "Pune University";

