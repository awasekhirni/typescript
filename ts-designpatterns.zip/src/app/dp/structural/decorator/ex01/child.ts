import Person from './person';
import PersonDecorator from './persondecorator';
class Child extends PersonDecorator{

    public Mother:Person;
    public Father:Person;
    public logParents(){
        console.log('Parents');
        this.Mother.identify();
        this.Father.identify();
    }
}
export default Child;