import Person from './person';

class SimplePerson implements Person{
    public name:string;
    public age:number;
    public identify(){
        console.log(`${this.name} age ${this.age}`);
    }
}

export default SimplePerson;