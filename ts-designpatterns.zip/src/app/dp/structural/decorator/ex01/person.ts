interface Person{
    name:string;
    age:number;
    identify():void
}

export default Person;