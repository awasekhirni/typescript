import PersonDecorator from './persondecorator';

class Student extends PersonDecorator{
    public school:string;
    public logSchool(){
        console.log(this.school);
    }

}

export default Student;