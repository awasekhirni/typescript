export namespace ElectricalSockets{
    
    export interface PlugConnector{
        socketType:string;
        voltage:string;
        giveElectricity():boolean;
    }

    export class GermanSocket implements PlugConnector{
        public socketType:string;
        public voltage:string;
        public giveElectricity():boolean{
                return true;
        }
    }

    export interface BritishPlugConnector{
        socketType:string;
        voltage:string;
        provideElectricity():boolean
    }

    export class BritishSocket implements BritishPlugConnector{
        socketType: string;
        voltage: string;
        provideElectricity(): boolean{
            return true;
        }
    }


    export class GermanToBritishAdapter implements BritishPlugConnector{
        private plug:PlugConnector;
        socketType: string;
        voltage: string;
        
        public GermantoBritishConnector(pg:PlugConnector){
            return true;
        }
        public provideElectricity():boolean{
            return true;
        }
    }
}