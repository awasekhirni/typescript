import * as es from './electricalsockets';
 let pg = new es.ElectricalSockets.GermanSocket();
 let uksocket=new es.ElectricalSockets.BritishSocket();
 let btogAdapter=new es.ElectricalSockets.GermanToBritishAdapter();
 btogAdapter.GermantoBritishConnector(pg);
