class LegacyAuthentication{
verifyEmail():boolean{
        return true;
    }
verifyPassword():boolean{
        return true;
    }
}

export default LegacyAuthentication;