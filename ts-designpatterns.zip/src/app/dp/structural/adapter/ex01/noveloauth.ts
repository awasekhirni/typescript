export class OAuth{
    
    twofactorAuth(login:string,pwd:string,mobilePIN:number):boolean{
        return true;
    }

    tokenbasedAuth(login:string,pwd:string, token:string):boolean{
        return true;
    }

    verifyEmail(email:string, pwd:string): boolean {
        return true;
    }
    verifyPassword(login:string, pwd:string): boolean {
        return true;
    }
    
}
export default OAuth;