import OAuth from './noveloauth';
import LegacyAuthentication from './legacyauth';

export default class AuthSystem extends OAuth{
    public legacy:LegacyAuthentication;
    public oAuth:OAuth;
    
    oldwayAuthentication(legacyAuthentication: LegacyAuthentication){
        this.legacy=legacyAuthentication;
        
    }

    nuovusAuthentication(oAuth:OAuth){
        this.oAuth=oAuth;
    }
}