import AuthSystem from './authsystem';
class client{
    loginProcess(login,password,email,mobilePIN?,token?){
    if(mobilePIN||token){
        let $newLoginSystem = new AuthSystem(); 
    }else {
        let $oldways = new AuthSystem();
       
    }
    }
}