import Composite from './composite';
import Leaf from './leaf';

let leafone = new Leaf("1");
let leaftwo = new Leaf("2");
let leafthree = new Leaf("3");

let compone = new Composite("CompositeOne");

let comptwo = new Composite("Compositetwo");

compone.add(leafone);
compone.add(leaftwo);
compone.add(leafthree);
compone.operation();