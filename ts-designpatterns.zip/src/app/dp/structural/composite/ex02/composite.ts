import IComponent from './icomponent'; 
class Composite implements IComponent{
    public list:IComponent[];
    private s:string;
    constructor(s:string){
        this.list=[];
        this.s=s;
    }
    public operation():void{
        console.log(`operation of composite ${this.s} is invoked!`);
        for(let i=0; i< this.list.length; i+=1){
            this.list[i].operation();
        }
    }

    public add(c:IComponent):void{
        this.list.push(c);
    }
    public remove(i:number){
        if(this.list.length <=1){
            throw new Error("index out of bounds"); 
            
        };
        this.list.splice(i,i===0?1:i);
    }

}

export default Composite;