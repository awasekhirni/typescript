import IComponent from './icomponent'; 
class Leaf implements IComponent{
     private s:string;

     constructor(s:string){
        this.s=s;
     }

     public operation():void{
         console.log(`operation of composite ${this.s} is invoked!`);
     }
}

export default Leaf;