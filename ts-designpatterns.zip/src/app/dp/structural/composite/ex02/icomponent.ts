interface IComponent{
    operation():void;
}
export default IComponent;