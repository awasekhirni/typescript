interface IBookmarkComponent{
    getName():string;
    getSize():number;
    getCount():number;
    getType():number;
    getData():string;
}

export default IBookmarkComponent;