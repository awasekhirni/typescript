import BookmarkCategory from './bookmarkcategory';
/**
  A collection keeping track of the root of the category / entry tree. 
*/
class Bookmarks {
    public root: BookmarkCategory;

    constructor() {
        this.root = new BookmarkCategory("root");
    }

    /**
      Add any object to the specified category following a specific syntax
      of name: url or name: children
    */
    private addToCategory(input: any, category: BookmarkCategory): void {
        for (let i in input) {
            if (input.hasOwnProperty(i)) {
                let value: any = input[i];
                if (typeof value === "string") {
                    category.AddBookmarkEntry(i, value);
                } else if (typeof value === "object") {
                    let newCategory: BookmarkCategory = new BookmarkCategory(i);
                    this.addToCategory(value, newCategory);
                    category.AddComponent(newCategory);
                } else {
                    throw new Error("What are thooooose?");
                }
            }
        }

        category.SortComponents();
    }

    /**
      Add any object to the root category following a specific syntax
      of name: url or name: children
    */
    public LoadData(input: any): void {
        this.addToCategory(input, this.root);
    }
}