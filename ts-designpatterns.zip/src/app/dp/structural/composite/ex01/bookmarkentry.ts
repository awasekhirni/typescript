import IBookmarkComponent from './bookmarkcomponent';
class BookmarkEntry implements IBookmarkComponent{

    constructor(public name:string, public url:string){
        this.name=name;
        this.url=url;
    }

    public getName(): string{
        return this.name;
    };
    public getSize(): number {
        return this.name.length+ this.url.length;
     };
    public getCount(): number {
        return 1;
     };
    public getType(): number {
        return 1;
     };
    public getData(): string {
        return this.url;
     };

}

export default BookmarkEntry;