import IBookmarkComponent from './bookmarkcomponent';

class BookmarkCategory implements IBookmarkComponent{
    public name:string;
    public components: Array<IBookmarkComponent>;
    constructor(name:string){
        this.name=name;
        this.components = new Array<IBookmarkComponent>();
    }
    public getName(): string {
        return this.name;
    };
    public getSize(): number {
        let result:number= this.name.length;
        for (let i = 0; i < this.components.length; i += 1) {
            result += this.components[i].getSize();
        }

        return result;
    };
    public getCount(): number {
        let result:number=1;
        for (let i = 0; i < this.components.length; i += 1) {
            result += this.components[i].getCount();
        }

        return result;
    };
    public getType(): number {
       return 2;
    };
    public getData(): string {
        return "";
    };


    public AddBookmarkEntry(name: string, url: string): void {
        this.AddComponent(new BookmarkEntry(name, url));
    }

    /**
      Add a component to the composition 
    */
    public AddComponent(component: IBookmarkComponent) {
        this.components.push(component);
    }

    /**
      Sort so that the categories appear on top
    */
    public SortComponents(): void {
        this.components.sort((a: IBookmarkComponent, b: IBookmarkComponent) => {
            if (a.getType() === b.getType()) {
                if (a.getName() < b.getName()) {
                    return -1;
                } else if (a.getName() > b.getName()) {
                    return 1;
                }

                return 0;
            }

            return (b.getType() - a.getType());
        });
    }

    /**
      Return the list of components in this composition
    */
    public getComponents(): Array<IBookmarkComponent> {
        return this.components;
    }

    

}

export default BookmarkCategory;