interface color{
    applyColor();
}
export default color;