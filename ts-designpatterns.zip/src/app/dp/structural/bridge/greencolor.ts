import Color from './color';
class GreenColor implements Color{
    applyColor():void{
        console.log("green");
    }
}

export default GreenColor;