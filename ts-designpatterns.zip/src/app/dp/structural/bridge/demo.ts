import Shape from './shape';
import Triange from './triangle';
import Pentagon from './pentagon';
import RedColor from './redcolor';
import GreenColor from './greencolor';
let st= new Triange(new RedColor());
let pt = new Pentagon(new GreenColor());