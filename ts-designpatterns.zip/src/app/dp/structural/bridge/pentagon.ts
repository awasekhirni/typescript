import Shape from './shape';
import Color from './color';

export default class Pentagon extends Shape {

    public color: Color;
    constructor(clr: Color) {
        super(clr);
    }
    applyColor(): void {

    };

}