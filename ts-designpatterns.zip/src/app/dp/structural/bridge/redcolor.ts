import Color from './color';
class RedColor implements Color {
    applyColor(): void {
        console.log("green");
    }
}

export default RedColor;