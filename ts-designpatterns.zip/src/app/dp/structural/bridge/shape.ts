import Color from './color';

 abstract class Shape{
    public color:Color; 
    constructor(clr:Color){

    }
    public abstract applyColor():void;

}

export default Shape;