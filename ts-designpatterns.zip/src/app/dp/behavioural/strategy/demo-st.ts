import SixteenPack from "./sixteenpack";
import Running from "./running";

const syedawase= new SixteenPack('Syed Awase', new Running());
syedawase.fitnessplan();