import FitnessStrategy from "./fitnessstrategy";


export default class SixteenPack{
    public strategy:FitnessStrategy;
    public name:String;
    constructor(name:string, strategy:FitnessStrategy){
        this.name=name;
        this.strategy=strategy;
    }

    fitnessplan():void{
        console.log(`${this.name} start the fitness plan:`);
        this.strategy.burnCalories();
    }

}