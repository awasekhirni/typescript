export default interface FitnessStrategy{
    burnCalories():void;
    dietaryIntake():void;
    stop?():void;
    schedule():void;
    weightWatch():void;
}