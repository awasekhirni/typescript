import FitnessStrategy from "./fitnessstrategy";

export default class Swimming implements FitnessStrategy{
    burnCalories(): void {
        console.log('You have burn calories by swimming');
      }
      dietaryIntake(): void {
        console.log('You have take gluten-free diet');
      }
      stop?(): void {
        console.log('stop and take rest');
      }
      schedule(): void {
        console.log('everyday, morning 15laps and evening 15 laps');
      }
      weightWatch(): void {
        console.log('only decreases 500gm in 1 week, do more: You want to be like salman khan!!');
      }
      
} 