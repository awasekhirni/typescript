export default interface MyIterator<T> {
  next(): T;
  hasNext(): boolean;
}
