import { MyIterator } from "./myiterator";

export interface MyCollection {
  createIterator(): MyIterator<Number>;
}
