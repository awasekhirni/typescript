import { MyIterator } from './myiterator';

export default class ConcreteIterator implements MyIterator<Number>{
   
    
    private _collection:Number[]=[];
    private _index:number=0;
    
    constructor(newCollection:Number[]){
        this._collection=newCollection;
    }

    next():any {
        const result=this._collection[this._index];
        this._index+=1;
        return result;
    }
    hasNext(): boolean {
        return this._index<this._collection.length;    
    }

    private log():void{
        console.log(`Logging ${this._collection[this._index]}`);
    }
  
    
}