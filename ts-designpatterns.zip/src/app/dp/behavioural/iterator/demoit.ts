import  DataCollection  from './datacollection';
import  MyIterator  from './myiterator';
const dc:DataCollection=new DataCollection([112,117,161628,17818712,187198]);
const itr:MyIterator<Number>= dc.createIterator();

while(itr.hasNext()){
    const number:Number=itr.next();
    console.log(`logging values:${number.valueOf()}`);
}