import { MyCollection } from './collection';

import ConcreteIterator from './concreteiterator';
import MyIterator from './myiterator';

export default class DataCollection implements MyCollection{
    private _collection:Number[]=[];
    constructor(collection:Number[]){
        this._collection=collection;
    }
    
    createIterator(): MyIterator<Number> {
        return new ConcreteIterator(this._collection);
    }
    
}