import Carnivore from './carnivore';
export default class Tiger implements Carnivore{
    attackforFood(): string {
        return "Tiger is attacking, i had no food since 3 days";
    }
    
}