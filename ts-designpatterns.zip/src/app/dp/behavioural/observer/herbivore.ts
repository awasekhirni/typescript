import Carnivore from "./carnivore";

//observable

export default abstract class Herbivore{
    protected carnivores:Carnivore[];

    public addCarnivore(carnivore:Carnivore){
        this.carnivores.push(carnivore);
    }
    public notifyAll():string{
        let scene:string="";
        for(let carnivore of this.carnivores){
            scene+=carnivore.attackforFood();
        }
        return scene;
    }

    public abstract shout():string;
}