import Tiger from "./tiger";
import Fox from "./fox";
import Deer from "./deer";


let sharekhan:Tiger = new Tiger(),
    lomdi:Fox = new Fox(); 

let dolly:Deer = new Deer();
dolly.addCarnivore(sharekhan);
dolly.addCarnivore(lomdi);
console.log(dolly.notifyAll());