import Herbivore from "./herbivore";

export default class Deer extends Herbivore{
    public shout(): string {
        throw new Error("Method not implemented.");
    }
    constructor(){
        super();
    }
}