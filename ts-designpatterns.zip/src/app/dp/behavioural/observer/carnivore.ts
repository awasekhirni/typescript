//observer
export default interface Carnivore{
    attackforFood():string;
}