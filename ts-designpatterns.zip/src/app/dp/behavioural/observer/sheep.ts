import Herbivore from "./herbivore";

export default class Sheep extends Herbivore{
    public shout(): string {
        throw new Error("Method not implemented.");
    }
    constructor(){
        super();
    }
}