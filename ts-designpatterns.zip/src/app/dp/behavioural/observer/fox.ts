import Carnivore from './carnivore';
export default class Fox implements Carnivore{
    attackforFood(): string {
        return "Foxy is attacking, i had no food since 3 days";
    }

}