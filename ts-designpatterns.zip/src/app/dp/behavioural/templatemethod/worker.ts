export default abstract class Worker{
    abstract DailyRoutine():void;
    abstract getUp():void;
    abstract eatBreakfast():void;
    abstract goToWork():void;
    abstract work():void;
    abstract returnToHome():void;
    abstract relax():void;
    abstract sleep():void;
}