import Worker from './worker';
export default class Lumberjack extends Worker{
    DailyRoutine(): void {
        throw new Error("Method not implemented.");
    }
    getUp(): void {
        throw new Error("Method not implemented.");
    }
    eatBreakfast(): void {
        throw new Error("Method not implemented.");
    }
    goToWork(): void {
        throw new Error("Method not implemented.");
    }
    work(): void {
        throw new Error("Method not implemented.");
    }
    returnToHome(): void {
        throw new Error("Method not implemented.");
    }
    relax(): void {
        throw new Error("Method not implemented.");
    }
    sleep(): void {
        throw new Error("Method not implemented.");
    }

}