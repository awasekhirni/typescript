import Hotel from "./hotel";
import Customer from './customer';
import Restaurant from './restaurant';
import Order from './iorder';

let customer: Customer = new Customer(),
    order: Order = new Hotel(customer),
    restaurant: Restaurant = new Restaurant();

restaurant.addOrder(order);
console.log(restaurant.prepareOrders());
