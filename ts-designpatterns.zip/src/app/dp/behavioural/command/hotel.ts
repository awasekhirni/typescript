import Order from "./iorder";
import Customer from './customer';

export default class Hotel implements Order {
    private customer: Customer;

    constructor(customer: Customer) {
        this.customer = customer;
    }

    public deliver(): string {
        return this.customer.pay();
    }
}