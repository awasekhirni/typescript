export default interface Order {
    deliver(): string;
}