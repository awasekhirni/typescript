export default class Customer {
    pay(): string {
        return "Payment OK!\n";
    }
}