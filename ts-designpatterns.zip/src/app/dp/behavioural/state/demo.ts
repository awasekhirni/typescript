import { ATMMachine } from "./atmmachine";


let mymac = new ATMMachine(10000);
mymac.takeCash(2000);// allows withdraw
mymac.takeCash(3000000);//error, does not have cash.