import { IATMState } from './iatmstate';
import { ATMMachine } from './atmmachine';
export class ATMHasCashState implements IATMState{
    private _machine:ATMMachine;
    name:string;
    constructor(machine:ATMMachine,name:string){
        this.name=name;
        this._machine=machine;

    }

    takeCash(cash: number): void {
        if (this._machine.cash < cash) {
          this._machine.state = this._machine.noCashState();
          console.log('Not enough cash');
          return;
        } else if (this._machine.cash === cash) {
          this._machine.state = this._machine.noCashState();
          console.log('No cash after cash token');
        }
        console.log(`${this._machine.cash} - ${cash}`);
        this._machine.cash -= cash;
      }
}