import { IATMState } from './iatmstate';
import { ATMMachine } from './atmmachine';

export class ATMNoCashState implements IATMState {
    private _machine: ATMMachine;
    name: string;
    constructor(machine: ATMMachine, name: string) {
      this.name = name;
      this._machine = machine;
    }
  
    takeCash(cash: number): void {
      throw new Error('ATMMachine has no cash');
    }
  }