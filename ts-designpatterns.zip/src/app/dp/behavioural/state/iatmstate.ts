export interface IATMState{
    name?:string;
    takeCash(cash:number):void;
}