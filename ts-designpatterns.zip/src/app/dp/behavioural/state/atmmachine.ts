import { ATMNoCashState } from './atmhasnocash';
import { ATMHasCashState } from './atmhaschash';
import { IATMState } from './iatmstate';
export class ATMMachine implements IATMState {

    private _hasCashState: ATMHasCashState;
    private _noCashState: ATMNoCashState;
  
    private _currentState: IATMState;
    
    public cash: number;
    
    constructor(cash: number) {
      this.cash = cash;
  
      this._hasCashState = new ATMHasCashState(this, 'HasCash');
      this._noCashState = new ATMNoCashState(this, 'NoCash');
  
      this._currentState = this.cash ? this._hasCashState : this._noCashState;
    }
  
    public set state(value: IATMState) {
      console.log(`Current state is ${value.name}`);
      this._currentState = value;
    }
  
    public get state() {
      return this._currentState;
    }
  
    takeCash(cash: number): void {
      this._currentState.takeCash(cash);
    }
  
    // Get states
    public hasCashState() {
      return this._hasCashState;
    }
  
    public noCashState() {
      return this._noCashState;
    }
  }