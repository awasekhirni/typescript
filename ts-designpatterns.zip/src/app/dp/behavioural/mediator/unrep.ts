import { IMediator } from './imediator';
import { Representative } from './representative';
export class UNRepresentative extends Representative{
    constructor(mediator:IMediator){
        super(mediator);

    }

    send(msg:string){
        console.log("message from UN representative");
        super.send(msg);
    }
}