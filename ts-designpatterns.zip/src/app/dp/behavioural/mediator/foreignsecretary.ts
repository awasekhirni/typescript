import { IMediator } from './imediator';
import { Representative } from './representative';
export class ForeignSecretary implements IMediator{
    
    public USForeignSecretary:Representative;
    public DPRKForeignSecretary:Representative;
    send(message: string, sender: Representative): void {
      if(sender===this.USForeignSecretary){
        this.USForeignSecretary.receiveMsg(message);
        this.DPRKForeignSecretary.receiveMsg(message);
      } 
      if(sender===this.DPRKForeignSecretary){
        this.USForeignSecretary.receiveMsg(message);
       
      } 
    }
}