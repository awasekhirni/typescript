import { HagueRepresentative } from './haguerep';
import { UNRepresentative } from './unrep';
import { ForeignSecretary } from './foreignsecretary';

const rep=new ForeignSecretary();
const trump= new UNRepresentative(rep);
const kimjong = new HagueRepresentative(rep);

rep.USForeignSecretary=trump;
rep.DPRKForeignSecretary=kimjong;


trump.send("hello! rocket man, i am going to ship you to mars");
kimjong.send("hello,dumbo, america is planning to ship you to saturn");
console.log("we are happy in earth without you ALL, please go and fight somewhere else!!");