import { Representative } from './representative';
import { IMediator } from './imediator';
export class HagueRepresentative extends Representative{
    
    constructor(mediator:IMediator){
        super(mediator);
    }

    send(msg:string){
        console.log("Message from HagueRepresentative");
        super.send(msg);
    }
}