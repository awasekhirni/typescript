import { IMediator } from './imediator';
export class Representative{
    public mediator:IMediator;
    constructor(mediator:IMediator){
        this.mediator=mediator;
    }

    send(msg:string):void{
        this.mediator.send(msg,this);
    }
    receiveMsg(msg:string):void{
        console.log(msg);
    }



}