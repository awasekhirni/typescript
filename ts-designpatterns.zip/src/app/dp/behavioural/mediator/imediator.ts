import { Representative } from './representative';
export interface IMediator{
    send(message:String,sender:Representative):void;
}