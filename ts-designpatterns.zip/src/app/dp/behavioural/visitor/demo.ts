import IMonument from "./imonument";
import Castle from "./castle";
import Fort from "./fort";
import IVisitor from "./ivisitor";
import Tourist from './tourist';



let castleRock:IMonument=new Castle(),
    redFort:IMonument=new Fort(),
    sak:IVisitor= new Tourist();

    console.log(castleRock.accept(sak));
    console.log(redFort.accept(sak));