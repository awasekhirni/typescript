import IVisitor from "./ivisitor";

export default interface IMonument{
    accept(visitor:IVisitor):string;
}