import IVisitor from "./ivisitor";
import IMonument from "./imonument";

export default interface Function{
    monumentName:string;
}

export default class Tourist implements IVisitor{
    visit(monument: IMonument): string {
        return `Visiting ${monument.constructor.monumentName}`;
    }

}