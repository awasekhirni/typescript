import IMonument from "./imonument";

export default interface IVisitor{
    visit(monument:IMonument):string;
}