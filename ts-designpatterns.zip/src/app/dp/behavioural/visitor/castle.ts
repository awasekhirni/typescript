import IMonument from "./imonument";
import IVisitor from "./ivisitor";

export default class Castle implements IMonument{
    accept(visitor: IVisitor): string {
        return visitor.visit(this);
    }

}