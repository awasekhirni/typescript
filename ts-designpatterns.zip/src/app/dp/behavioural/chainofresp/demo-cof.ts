import { EventEmitter } from 'events';
import { Order } from './iorder';
import { OrderManagementSystem } from "./ordermgmtsystem";
import { ComplianceSystem } from "./compliancesystem";



let ooms= new OrderManagementSystem();
let cms = new ComplianceSystem();
//order
//tracking