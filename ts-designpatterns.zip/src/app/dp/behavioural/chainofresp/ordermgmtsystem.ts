import { Order } from "./iorder";
import { EventEmitter } from "events";
import { Execution } from "./iexecution";
export class OrderManagementSystem {
  messageBus = new EventEmitter();
  constructor() {
    this.messageBus.on("order", orderMessage => {
      this.processOrder(orderMessage as Order);
    });
    this.messageBus.on("execution", executionMessage => {
      this.processExecution(executionMessage as Execution);
    });
  }
  processExecution(execution: Execution) {
    console.log(
      new Date().getTime() + ":OMS:execution:" + JSON.stringify(execution)
    );
  }

  processOrder(order: Order): void {
    console.log(new Date().getTime() + ":OMS:order:" + JSON.stringify(order));
    var numberOfExecutions = 10;
    var quantityPerExecution = order.quantity / numberOfExecutions;
    for (var i = 0; i < numberOfExecutions; i++) {
      this.messageBus.emit("execution", {
        orderId: order.orderId,
        executionId: i,
        symbol: order.symbol,
        quantity: quantityPerExecution,
        price: 101.5
      });
    }
  }
}
