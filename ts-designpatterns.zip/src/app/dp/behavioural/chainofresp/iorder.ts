export interface Order{
    orderId:number,
    option:"Buy"|"Sell",
    symbol:string,
    quantity:number
}