import { Execution } from './iexecution';
import { Order } from './iorder';
import { EventEmitter } from 'events';


export class ComplianceSystem{
   messageBus= new EventEmitter();

    constructor() {
        this.messageBus.on("order", (orderMessage) => {
           this.trackOrder(orderMessage as Order); 
        });
        this.messageBus.on("execution", (executionMessage) => {
            this.trackExecution(executionMessage as Execution);
        })
    } 
    
    trackOrder(order:Order) {
        console.log(new Date().getTime()+":COMPLIANCE:order:"+JSON.stringify(order));
    }
    
    trackExecution(execution:Execution) {
        console.log(new Date().getTime()+":COMPLIANCE:execution:"+JSON.stringify(execution));
    }
}