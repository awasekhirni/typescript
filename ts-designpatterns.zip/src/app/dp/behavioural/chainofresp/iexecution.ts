export interface Execution{
    orderId:number,
    executionId:number,
    symbol:string;
    quantity:number;
    price:number;
}