export interface IAudible{
    isTrackPlaying:boolean,
    turnOn:void;
    playSelection(preset:number):void;
    turnOff():void;
}