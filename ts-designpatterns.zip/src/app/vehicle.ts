export class Vehicle{
    private _currentMiles:number;
    private _moving:boolean=false;
    private _avlblgas:number;
    private _milespergalon:number; 

    public name:string;
    public type:string;
    public audioSystem:IAudible;

    constructor(mpg=12,fuel:number=10){
        this._milespergalon=mpg;
        this._avlblgas=fuel;
        this._currentMiles=0;
    }

    public shiftGear():void{
        console.log(this.name,"Shifted the car gear");
    }

    public applyBrakes():void{
        console.log(this.name, "applied brakes");
    }

    public drive():void{
        console.log(this.name,"drive the car");
    }

    public getGasMileage():number{
        return this._avlblgas;
    }

    public setGasMileage(mpg:number):void{
        this._avlblgas=mpg;
    }

}