class Animal{
    public type:string;
    public domestic:boolean;
    public carnivore:boolean;
    constructor(type,domestic,carnivore){
        this.type=type;
        this.domestic = domestic;
        this.carnivore=carnivore;
    }
}

export default Animal;