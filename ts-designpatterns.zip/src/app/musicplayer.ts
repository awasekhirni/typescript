import {IAudible} from './iaudible';

export class MusicPlayer implements IAudible{
    isTrackPlaying: boolean;
    turnOn: void;
    constructor(){
        this.isTrackPlaying=false;
    }
    playSelection(preset: number): void {
        this.isTrackPlaying=true;
     }
    turnOff(): void {
        this.isTrackPlaying=false;    
     }

     public eject():void{
         console.log("Please eject the CD player");
     }

}