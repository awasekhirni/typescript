import Animal from './animal';

class BrunoDog extends Animal{
    public family:string;
    constructor(type:string,domestic:boolean,carnivore:boolean, family:string){
        super(type,domestic,carnivore);
        this.type="German Shepherd";
        this.domestic=true;
        this.carnivore=true;
    }
}

export default BrunoDog;